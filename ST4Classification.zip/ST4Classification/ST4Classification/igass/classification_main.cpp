#include <time.h>
#include <opencv2/core/core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\opencv.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <opencv2/ml/ml.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <math.h>
#include "classification.h"

using namespace cv;
using namespace std;

int main(int argc, char* argv[])
{	
	////////////////////////////// test finished!
	if(argc==1)
	{
		cout<<"welcome to Hyperspectral supervised-classification based on EAF"<<endl;
		cout<<"Author: Li Lu"<<endl;
		cout<<"email: l7170@sina.com \nTel:(+086)17090086991"<<endl;
		cout<<"Usage: igass.exe Mask.xml outfile test.bin [optional]"<<endl;
		cout<<"Mask.xml-------Mask,train-set generate by generate_trainset.exe"<<endl;
		cout<<"outfile-------using train.xml and test.xml generate by LIBSVM"<<endl;
		cout<<"test.bin-------binary file record hyperspectral image, generate by matlab file mat2binary.m"<<endl;
		cout<<"optional 1-----------default means filtering by segment-tree filtering,0--------filtering by guided filtering,"<<endl;
		waitKey();
		exit(0);
	}
	int maxnum_class(0);/////////////////////////////������
	FileStorage fs;
	fs.open(argv[1],FileStorage::READ);
	Mat Mask,labelsMat,trainingDataMat_ori,train,testDataMat,testlab;
	fs["Mask"]>>Mask;
	fs["labelsMat"]>>labelsMat;
	fs["trainingDataMat_ori"]>>trainingDataMat_ori;
	fs["train"]>>train;
	fs["testDataMat"]>>testDataMat;
	fs.release();
	int num_trainset=trainingDataMat_ori.rows;
	int channel=trainingDataMat_ori.cols;
	double **scale_ori=new double* [channel];
	for(int i=0;i<channel;i++)
		scale_ori[i]=new double[2];
	for(int i=0;i<channel;i++)
	{
		minMaxLoc(testDataMat.col(i),&scale_ori[i][0],&scale_ori[i][1]);
	}
	for(int i=0;i<num_trainset;i++)
	{
		for(int j=0;j<channel;j++)
			trainingDataMat_ori.at<double>(i,j)=(trainingDataMat_ori.at<double>(i,j)-scale_ori[j][0])/(scale_ori[j][1]-scale_ori[j][0]);
	}
	for(int i=0;i<num_trainset;i++)
	{
		for(int j=0;j<channel;j++)
			testDataMat.at<double>(i,j)=(testDataMat.at<double>(i,j)-scale_ori[j][0])/(scale_ori[j][1]-scale_ori[j][0]);
	}
	int m=Mask.rows;
	int n=Mask.cols;
	{
		double temp;
		minMaxLoc(labelsMat,NULL,&temp);		
		maxnum_class=(int)temp;
	}
	int allnum=countNonZero(Mask);
	ifstream infile(argv[3],ios::binary);
	if(!infile)
	{
		cerr<<"open error!"<<endl;
		abort();
	}
	double*** img=allocd_3(channel,m,n);
	for(int k=0;k<channel;k++)
	{
		for(int j=0;j<n;j++)
		{
			for(int i=0;i<m;i++)
			{
				infile.read((char*)&img[k][i][j],sizeof(double));
			}
		}
	}
	infile.close();
    Mat trans_LDA=LDA_trans(trainingDataMat_ori,labelsMat,3);
	Mat trans_PCA=SELF(trainingDataMat_ori,labelsMat,testDataMat,1,3);
    Mat trans_SELF=SELF(trainingDataMat_ori,labelsMat,testDataMat,0.5,10);
	Mat trans_LFDA=SELF(trainingDataMat_ori,labelsMat,testDataMat,0.001,3);
	Mat IMG_MAT(m*n,channel,CV_64FC1,Scalar(0));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<channel;k++)
				IMG_MAT.at<double>(i*n+j,k)=img[k][i][j];
		}
	}
	Mat showLDA,showPCA,showSELF,showLFDA;
	showimg_trans(IMG_MAT,trans_LDA,m,n,showLDA);
	showimg_trans(IMG_MAT,trans_PCA,m,n,showPCA);
	vector<Mat> SELF_img=showimg_trans(IMG_MAT,trans_SELF,m,n,showSELF);
	showimg_trans(IMG_MAT,trans_LFDA,m,n,showLFDA);
	imshow("showLDA.jpg",showLDA);
	imwrite("showLDA.jpg",showLDA);
	imshow("showPCA.jpg",showPCA);
	imwrite("showPCA.jpg",showPCA);
	imshow("showSELF.jpg",showSELF);
	imwrite("showSELF.jpg",showSELF);	
	imshow("showLFDA.jpg",showLFDA);
	imwrite("showLFDA.jpg",showLFDA);
	waitKey();
	//trans_SELF=Mat::eye(channel,channel,CV_64FC1);
	//Mat Trans_trainingDataMat_ori=trainingDataMat_ori*trans_SELF;
	//int ch=Trans_trainingDataMat_ori.cols;
	/////////////////////////////////Scale to [-1,1]
	//Mat scale4channel(ch,2,CV_64FC1,Scalar(0.0));
	//for(int i=0;i<ch;i++)
	//{
	//	double maxval=0,minval=0;
	//	minMaxLoc(Trans_trainingDataMat_ori.col(i),&minval,&maxval);
	//	double scale=0.5f*double(maxval-minval);
	//	double offset=double(minval+scale);
	//	scale4channel.at<double>(i,0)=scale;
	//	scale4channel.at<double>(i,1)=offset;
	//}
	//	
	//for(int j=0;j<ch;j++)
	//{
	//	double scale=scale4channel.at<double>(j,0);
	//	double offset=scale4channel.at<double>(j,1);
	//	for(int i=0;i<num_trainset;i++)
	//	{
	//		Trans_trainingDataMat_ori.at<double>(i,j)=(Trans_trainingDataMat_ori.at<double>(i,j)-offset)/scale;
	//	}
	//}
	FILE* fpoutrain=fopen("train.xml","wt");
	for(int i=0;i<num_trainset;i++)
	{
		fprintf(fpoutrain,"%d ",(int)labelsMat.at<int>(i,0));
		for(int j=0;j<channel;j++)
		{
			fprintf(fpoutrain,"%d:%f ",j+1,trainingDataMat_ori.at<double>(i,j));
		}
		fprintf(fpoutrain,"\n");
	}
	fclose(fpoutrain);
	
	FILE* fpoutest=fopen("test.xml","wt");
	int total_test=0;
	vector<Point3i> testid;
	Mat labtest(allnum,1,CV_32SC1,Scalar(0));
	Mat test_ori(allnum,channel,CV_64FC1,Scalar(0));


	Mat test_ori2(allnum,channel,CV_64FC1,Scalar(0));
	int idall=0;
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{	
			if(Mask.at<uchar>(i,j))
			{
				testid.push_back(Point3i(i,j,(int)Mask.at<uchar>(i,j)));
				Mat sampleMat(1,channel,CV_64FC1,Scalar(0));
				labtest.at<int>(idall,0)=(int)Mask.at<uchar>(i,j);
				fprintf(fpoutest,"%d ",(int)Mask.at<uchar>(i,j));
				for(int k=0;k<channel;k++)
				{	
					sampleMat.at<double>(0,k)=(img[k][i][j]-scale_ori[k][0])/(scale_ori[k][1]-scale_ori[k][0]);
					test_ori2.at<double>(idall,k)=(img[k][i][j]-scale_ori[k][0])/(scale_ori[k][1]-scale_ori[k][0]);
				}
	
				//Mat trans_sampleMat=sampleMat*trans_SELF;
				for(int k=0;k<channel;k++)
				{	
					test_ori.at<double>(idall,k)=sampleMat.at<double>(0,k);//-scale4channel.at<double>(k,1))/scale4channel.at<double>(k,0);
					fprintf(fpoutest,"%d:%lf ",k+1,test_ori.at<double>(idall,k));
				}
				fprintf(fpoutest,"\n");

				idall++;

			}			
		}
	}
	fclose(fpoutest);
	for(int i=0;i<channel;i++)
	{
		delete[]scale_ori[i];
		scale_ori[i]=NULL;
	}
	delete[]scale_ori;
	scale_ori=NULL;
	freed_3(img);
	vector<Mat> weightmap;
	for(int i=0;i<maxnum_class;i++)
	{
		Mat temp(m,n,CV_64FC1,Scalar(0.0));
		weightmap.push_back(temp);
	}
	Mat labels_svm(m,n,CV_32SC1,Scalar(0));
	//////////////////
	Mat Trans_trainingDataMat_ori=trainingDataMat_ori*trans_SELF;
	int ch=Trans_trainingDataMat_ori.cols;
	Mat Trans_testDataMat=test_ori2*trans_SELF;
	Mat Prob=seim_supervised_knn(Trans_trainingDataMat_ori,labelsMat,Trans_testDataMat,10,5,2);
	Mat result;
	//Mat Prob=EM_Semi_Supervised_classification(Trans_trainingDataMat_ori,Trans_testDataMat,labelsMat,16,result);
	for(int i=0;i<allnum;i++)
	{
		int x=testid[i].x;
		int y=testid[i].y;		
		for(int j=0;j<maxnum_class;j++)
			weightmap[j].at<double>(x,y)=100*Prob.at<double>(i,j);
		double maxv=Prob.at<double>(i,0);
		int temp=0;
		for(int j=1;j<maxnum_class;j++)
		{
			if(Prob.at<double>(i,j)>maxv)
			{
				maxv=Prob.at<double>(i,j);
				temp=j;
			}
		}
		labels_svm.at<int>(x,y)=temp+1;
	}
	////////////////
	//FILE* fpsoft=fopen(argv[2],"rt");
	//char buffer[10000];
	//fgets(buffer,10000,fpsoft);
	//int idx=0;
	//while(!feof(fpsoft))
	//{
	//	double temp;
	//	fscanf(fpsoft,"%lf ",&temp);
	//	if(idx%(maxnum_class+1)==0) 
	//	{
	//		labels_svm.at<int>(testid[idx/(maxnum_class+1)].x,testid[idx/(maxnum_class+1)].y)=temp;
	//		//weightmap[temp-1].at<double>(testid[idx/(maxnum_class+1)].x,testid[idx/(maxnum_class+1)].y)=1.0;
	//		idx++;
	//		continue;
	//	}
	//	weightmap[idx%(maxnum_class+1)-1].at<double>(testid[idx/(maxnum_class+1)].x,testid[idx/(maxnum_class+1)].y)=temp;
	//	idx++;
	//}	
	//fclose(fpsoft);

	for(int i=0;i<train.rows;i++)
	{
		int lab =train.at<int>(i,2);
		int x=train.at<int>(i,0);
		int y=train.at<int>(i,1);
		for(int j=0;j<maxnum_class;j++)
		{
			if(j==lab)
				weightmap[j].at<double>(x,y)=100.0;
			else
				weightmap[j].at<double>(x,y)=0.0;
		}
	}

	Accury_Evalution(testid,maxnum_class,labels_svm,1,"inital_accury.xml");
	Mat dispresult(m,n,CV_8UC3,Scalar(0,0,0));
	vector<Vec3b> color_map(16);

	color_map[0]=Vec3b(255,0,0);
	color_map[1]=Vec3b(0,255,0);
	color_map[2]=Vec3b(0,0,255);
	color_map[3]=Vec3b(125,125,0);
	color_map[4]=Vec3b(0,125,125);
	color_map[5]=Vec3b(125,0,125);
	color_map[6]=Vec3b(100,200,100);
	color_map[7]=Vec3b(200,50,200);
	color_map[8]=Vec3b(120,60,200);
	color_map[9]=Vec3b(100,150,210);
	color_map[10]=Vec3b(80,180,210);
	color_map[11]=Vec3b(90,200,200);
	color_map[12]=Vec3b(100,220,80);
	color_map[13]=Vec3b(70,10,20);
	color_map[14]=Vec3b(60,50,30);
	color_map[15]=Vec3b(30,50,20);
	Mat groundtruth(m,n,CV_8UC3,Scalar(0,0,0));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{	
			if(Mask.at<uchar>(i,j)!=0)
			{
				dispresult.at<Vec3b>(i,j)=color_map[labels_svm.at<int>(i,j)-1];	
				groundtruth.at<Vec3b>(i,j)=color_map[Mask.at<uchar>(i,j)-1];
				//weightmap[labels_svm.at<int>(i,j)-1].at<double>(i,j)=1.0;
			}
		}
	}	
	namedWindow("initial_classification",WINDOW_AUTOSIZE);
	imshow("initial_classification",dispresult);
	imwrite("initial_classification_svm.png",dispresult);
	imshow("groundtruth.png",groundtruth);
	imwrite("groundtruth.png",groundtruth);
	waitKey();

	// vector<Mat> LDA_img=show_LDA(m,n,trainingDataMat_ori,labelsMat,maxnum_class,0,img,0);//showPCA(m,n,3,img,Mat());//showLDA(m,n,trainingDataMat_ori,labelsMat,maxnum_class,3,img,0);
//    //////////////////////////////////////////////train-set Mat initializiation
//	/////////////////////////////////Scale to [-1,1]
//	//Mat scale4channel(channel,2,CV_32FC1,Scalar(0.f));
//	//for(int i=0;i<channel;i++)
//	//{
//	//	double maxval=0,minval=0;
//	//	minMaxLoc(trainingDataMat.col(i),&minval,&maxval);
//	//	float scale=0.5f*float(maxval-minval);
//	//	float offset=float(minval+scale);
//	//	scale4channel.at<float>(i,0)=scale;
//	//	scale4channel.at<float>(i,1)=offset;
//	//}
//	//
//	//for(int j=0;j<channel;j++)
//	//{
//	//	float scale=scale4channel.at<float>(j,0);
//	//	float offset=scale4channel.at<float>(j,1);
//	//	for(int i=0;i<num_trainset;i++)
//	//	{
//	//		trainingDataMat.at<float>(i,j)=(trainingDataMat.at<float>(i,j)-offset)/scale;
//	//	}
//	//}
//
//	//FILE* fpoutrain=fopen("train.xml","wt");
//	//for(int i=0;i<num_trainset;i++)
//	//{
//	//	fprintf(fpoutrain,"%d ",(int)labelsMat.at<float>(i,0));
//	//	for(int j=0;j<channel;j++)
//	//	{
//	//		fprintf(fpoutrain,"%d:%f ",j+1,trainingDataMat.at<float>(i,j));
//	//	}
//	//	fprintf(fpoutrain,"\n");
//	//}
//	//fclose(fpoutrain);
//
//	////// Set up SVM��s parameters
//	//CvSVMParams params;
//	//params.svm_type = CvSVM::C_SVC;
//	//params.kernel_type = CvSVM::RBF;
//	//params.term_crit = cvTermCriteria(CV_TERMCRIT_ITER, 100, 1e-6);	
//	//CvParamGrid grid(0,0,0);
// //   // Train the SVM
// //   CvSVM SVM;
//	//SVM.train_auto(trainingDataMat, labelsMat, Mat(), Mat(), params,5,CvSVM::get_default_grid(CvSVM::C),
//	//	CvSVM::get_default_grid(CvSVM::GAMMA),grid,grid,grid,grid,false);
//	//Mat labels_svm(m,n,CV_32SC1,Scalar(0));
//
//	Mat labels_svm(m,n,CV_32SC1,Scalar(0));
//	vector<Mat> weightmap;
//	for(int i=0;i<maxnum_class;i++)
//	{
//		Mat temp(m,n,CV_64FC1,Scalar(0.0));
//		weightmap.push_back(temp);
//	}
//	FILE* fpsoft=fopen("outfile","rt");
//	char buffer[10000];
//	fgets(buffer,10000,fpsoft);
//	int idx=0;
//	while(!feof(fpsoft))
//	{
//		double temp;
//		fscanf(fpsoft,"%lf ",&temp);
//		if(idx%(maxnum_class+1)==0) 
//		{
//			labels_svm.at<int>(testid[idx/(maxnum_class+1)].x,testid[idx/(maxnum_class+1)].y)=temp;
//			idx++;
//			continue;
//		}
//		weightmap[idx%(maxnum_class+1)-1].at<double>(testid[idx/(maxnum_class+1)].x,testid[idx/(maxnum_class+1)].y)=temp;
//		idx++;
//	}	
//	fclose(fpsoft);
//	////////////////////////////////////////////////train-set do not be doubt 
//	for(int i=0;i<train.rows;i++)
//	{
//		int lab =train.at<int>(i,2);
//		int x=train.at<int>(i,0);
//		int y=train.at<int>(i,1);
//		for(int j=0;j<maxnum_class;j++)
//		{
//			if(j==lab)
//			    weightmap[j].at<double>(x,y)=1.0;
//			else
//				weightmap[j].at<double>(x,y)=0.0;
//		}
//	}
//	////////////////////////////////////////////////
//
//
//
//	Accury_Evalution(testid,maxnum_class,labels_svm,1,"inital_accury.xml");
//
//	//FILE* fpoutest=fopen("test.xml","wt");
//	//// predict
//	//int total_test=0;
//	//for(int i=0;i<m;i++)
//	//{
//	//	for(int j=0;j<n;j++)
//	//	{	
//	//		if(Mask.at<uchar>(i,j))
//	//		{
//	//			Mat sampleMat(1,channel,CV_32FC1,Scalar(0));
//	//			fprintf(fpoutest,"%d ",(int)Mask.at<uchar>(i,j));
//	//			for(int k=0;k<channel;k++)
//	//			{	
//	//				sampleMat.at<float>(0,k)=((float)img[k][i][j]-scale4channel.at<float>(k,1))/scale4channel.at<float>(k,0);
//	//				fprintf(fpoutest,"%d:%f ",k+1,sampleMat.at<float>(0,k));
//	//			}
//	//			fprintf(fpoutest,"\n");
//	//			//Mat result;
//	//			float response = SVM.predict(sampleMat);
//	//				//SVM.predict(sampleMat,result);
//	//				//cout<<result<<endl;
//	//			labels_svm.at<int>(i,j)=(int)response;
//	//			total_test++;
//	//			testid.push_back(Point2i(i,j));
//	//		}			
//	//	}
//	//}
//	//fclose(fpoutest);
//
//	
//	Mat dispresult(m,n,CV_8UC3,Scalar(0,0,0));
//	vector<Vec3b> color_map(16);
//	//std::srand((unsigned)time(NULL));
//	//for(int i=0;i<maxnum_class;i++)
//	//{
//	//	color_map[i]=Vec3b((rand()%255),(rand()%255),(rand()%255));
//	//}
//
//	color_map[0]=Vec3b(255,0,0);
//	color_map[1]=Vec3b(0,255,0);
//	color_map[2]=Vec3b(0,0,255);
//	color_map[3]=Vec3b(125,125,0);
//	color_map[4]=Vec3b(0,125,125);
//	color_map[5]=Vec3b(125,0,125);
//	color_map[6]=Vec3b(100,200,100);
//	color_map[7]=Vec3b(200,50,200);
//	color_map[8]=Vec3b(120,60,200);
//	color_map[9]=Vec3b(100,150,210);
//	color_map[10]=Vec3b(80,180,210);
//	color_map[11]=Vec3b(90,200,200);
//	color_map[12]=Vec3b(100,220,80);
//	color_map[13]=Vec3b(70,10,20);
//	color_map[14]=Vec3b(60,50,30);
//	color_map[15]=Vec3b(30,50,20);
//	Mat groundtruth(m,n,CV_8UC3,Scalar(0,0,0));
//	for(int i=0;i<m;i++)
//	{
//		for(int j=0;j<n;j++)
//		{	
//			if(Mask.at<uchar>(i,j)!=0)
//			{
//				dispresult.at<Vec3b>(i,j)=color_map[labels_svm.at<int>(i,j)-1];	
//				groundtruth.at<Vec3b>(i,j)=color_map[Mask.at<uchar>(i,j)-1];
//				//weightmap[labels_svm.at<int>(i,j)-1].at<double>(i,j)=1.0;
//			}
//		}
//	}	
//	namedWindow("initial_classification",WINDOW_AUTOSIZE);
//	imshow("initial_classification",dispresult);
//	imwrite("initial_classification_svm.png",dispresult);
//	imshow("groundtruth.png",groundtruth);
//	imwrite("groundtruth.png",groundtruth);
//    waitKey();
//
//	//Mat PCA_img=showPCA(m,n,channel,img,Mat());
//	////////////////////////////////////////////////evalution
	Mat search_Accury(1,100,CV_64FC1,Scalar(0.0));
	Mat stat_eval(m,n,CV_32SC1,Scalar(0.0));
	Mat display(m,n,CV_8UC3,Scalar(0,0,0));
//	//vector<Mat> LDA_img=showLDA(m,n,trainingDataMat_ori,labelsMat,maxnum_class,0,img,0);//showPCA(m,n,3,img,Mat());//showLDA(m,n,trainingDataMat_ori,labelsMat,maxnum_class,3,img,0);
//	freed_3(img);
	int op=atoi(argv[4]);//0;//
	if(op)////////////////////////////////////////filtering with segments-tree
	{
		vector<int> node_seq,nr_children_seq,parent_seq;
		vector<double>weight_seq;
		vector<vector<int>> children_seq;
		double t=(double)getTickCount();
		Segments_tree(SELF_img,node_seq,nr_children_seq,children_seq,parent_seq,weight_seq);
		t = ((double)getTickCount() - t)/getTickFrequency();
		cout<<t<<endl;
		/////////////////////////
		double tempsigma=0.0;
		for(int i=0;i<(int)weight_seq.size();i++)
		{
			tempsigma+=weight_seq[i];
		}
		double mean_=tempsigma/(double)weight_seq.size();
		tempsigma=0.0;
		for(int i=0;i<(int)weight_seq.size();i++)
		{
			tempsigma+=pow(weight_seq[i],2);
		}
		double sigma=sqrt(tempsigma/((double)weight_seq.size()-1.0));
		cout<<"mean: "<<mean_<<endl;
		cout<<"sigma: "<<sigma<<endl;

		//double sigma=0.12;//0.0915;//0.634771;//((maxloc.x)+1)*0.01;
		cout<<"at sigma: "<<sigma<<endl;
		 t=(double)getTickCount();
		vector<Mat>agg=Non_Local_filter(weightmap,node_seq,nr_children_seq,children_seq,weight_seq,parent_seq,3*sigma);	
		t = ((double)getTickCount() - t)/getTickFrequency();
		cout<<t<<endl;
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(Mask.at<uchar>(i,j)!=0)
				{					
					int tempmax=0;
					double tempvalue=agg[0].at<double>(i,j);
					for(int k=1;k<maxnum_class;k++)
					{
						if(tempvalue<agg[k].at<double>(i,j))
						{
							tempvalue=agg[k].at<double>(i,j);
							tempmax=k;
						}
					}
					stat_eval.at<int>(i,j)=tempmax+1;
					display.at<Vec3b>(i,j)=color_map[tempmax];
				}			
			}
			
		}
		search_Accury.at<double>(0,0)=Accury_Evalution(testid,maxnum_class,stat_eval);		
	}
	else////////////////////////////////////////filtering with guided filtering
	{
		Mat search_Accury(10,15,CV_64FC1,Scalar(0.0));
		for(int kr=1;kr<11;kr++)
		{
			cout<<(kr-1)*10<<"%"<<endl;
			for(int keps=1;keps<=15;keps++)
			{
				int windows_radius=kr*2+1;
				double eps=pow(2.0,-keps);
				vector<Mat> after_GF(maxnum_class);
				for(int i=0;i<maxnum_class;i++)
					after_GF[i]=Guidedfilter_color(SELF_img,weightmap[i],windows_radius,eps);
				Mat stat_eval(m,n,CV_32SC1,Scalar(0));
				for(int i=0;i<m;i++)
				{
					for(int j=0;j<n;j++)
					{
						if(Mask.at<uchar>(i,j)!=0)
						{
							int tempmax=0;
							float tempvalue=after_GF[0].at<double>(i,j);
							for(int k=1;k<maxnum_class;k++)
							{
								if(tempvalue<after_GF[k].at<double>(i,j))
								{
									tempvalue=after_GF[k].at<double>(i,j);
									tempmax=k;
								}
							}
							stat_eval.at<int>(i,j)=tempmax+1;
						}			
					}
				}
				search_Accury.at<double>(kr-1,keps-1)=Accury_Evalution(testid,maxnum_class,stat_eval);
			}
		}	
		cout<<"search_Accury: "<<search_Accury<<endl;
		double max_acc;
		Point maxloc;
		minMaxLoc(search_Accury,NULL,&max_acc,NULL,&maxloc,noArray());

		int windows_radius=2*(5+1)+1;//11maxloc.y;
		double eps=0.0001;//pow(2.0,-(+1));//0.5maxloc.x;
		cout<<"at windows_size:"<<windows_radius<<endl;
		cout<<"at sigma: "<<eps<<endl;
		vector<Mat> after_GF(maxnum_class);

		double t=(double)getTickCount();
		for(int i=0;i<maxnum_class;i++)
			after_GF[i]=Guidedfilter_color(SELF_img,weightmap[i],windows_radius,eps);
		t = ((double)getTickCount() - t)/getTickFrequency();
		cout<<t<<endl;

		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(Mask.at<uchar>(i,j)!=0)
				{
					int tempmax=0;
					float tempvalue=after_GF[0].at<double>(i,j);
					for(int k=1;k<maxnum_class;k++)
					{
						if(tempvalue<after_GF[k].at<double>(i,j))
						{
							tempvalue=after_GF[k].at<double>(i,j);
							tempmax=k;
						}
					}
					stat_eval.at<int>(i,j)=tempmax+1;
					display.at<Vec3b>(i,j)=color_map[tempmax];
				}			
			}
		}
	}
	
	//double tempsigma=0.0;
	//for(int i=0;i<(int)weight_seq.size();i++)
	//{
	//	tempsigma+=weight_seq[i];
	//}
	//double mean_=tempsigma/(double)weight_seq.size();
	//tempsigma=0.0;
	//for(int i=0;i<(int)weight_seq.size();i++)
	//{
	//	tempsigma+=pow(weight_seq[i],2);
	//}
	//double sigma=sqrt(tempsigma/((double)weight_seq.size()-1.0));
	//cout<<mean_<<endl;
	//cout<<sigma<<endl;
	//for(int k1=1;k1<=100;k1++)
	//{	
	//	double sigma0=0.01*k1;	//0.29
	//	vector<Mat>agg=Non_Local_filter(weightmap,node_seq,nr_children_seq,children_seq,weight_seq,parent_seq,sigma0);

	//	for(int i=0;i<m;i++)
	//	{
	//		for(int j=0;j<n;j++)
	//		{
	//			if(Mask.at<uchar>(i,j)!=0)
	//			{
	//				int tempmax=0;
	//				double tempvalue=agg[0].at<double>(i,j);
	//				for(int k=1;k<maxnum_class;k++)
	//				{
	//					if(tempvalue<agg[k].at<double>(i,j))
	//					{
	//						tempvalue=agg[k].at<double>(i,j);
	//						tempmax=k;
	//					}
	//				}
	//				stat_eval.at<int>(i,j)=tempmax+1;
	//			}			
	//		}
	//	}
	//	search_Accury.at<double>(0,k1)=Accury_Evalution(testid,maxnum_class,stat_eval);
	//}
	//}
	
	
	/////////////////////////////////////////////////////////////////////////////////
	//
	

	


	//
	//int windows_radius=2*(maxloc.y+2)+1;
	//double eps=pow(2.0,-(maxloc.x+1));
	//cout<<"at windows_size:"<<windows_radius<<endl;
	//cout<<"at sigma: "<<eps<<endl;
	//vector<Mat> after_GF(maxnum_class);
	//for(int i=0;i<maxnum_class;i++)
	//	after_GF[i]=Guidedfilter_color(LDA_img,weightmap[i],windows_radius,eps);
	//Mat stat_eval(m,n,CV_32SC1,Scalar(0));
	//for(int i=0;i<m;i++)
	//{
	//	for(int j=0;j<n;j++)
	//	{
	//		if(Mask.at<uchar>(i,j)!=0)
	//		{
	//			int tempmax=0;
	//			float tempvalue=after_GF[0].at<double>(i,j);
	//			for(int k=1;k<maxnum_class;k++)
	//			{
	//				if(tempvalue<after_GF[k].at<double>(i,j))
	//				{
	//					tempvalue=after_GF[k].at<double>(i,j);
	//					tempmax=k;
	//				}
	//			}
	//			stat_eval.at<int>(i,j)=tempmax+1;
	//			display.at<Vec3b>(i,j)=color_map[tempmax];
	//		}			
	//	}
	//}	
	Accury_Evalution(testid,maxnum_class,stat_eval,1,"final_accury.xml");
	namedWindow("final_result",CV_WINDOW_AUTOSIZE);
	imshow("final_result",display);
	imwrite("final_result.png",display);	
	waitKey();
//	Accury_Evalution(Testlist,maxnum_class,stat_eval,1);
	//FileStorage fsa;
	//fsa.open("search_Accury.xml",FileStorage::WRITE);
	//fsa<<"search_Accury"<<search_Accury;
	//fsa.release();	

	return 1;
}
