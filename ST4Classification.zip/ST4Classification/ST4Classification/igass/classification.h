#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <iostream>
#include <time.h>
#include <opencv2/core/core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\opencv.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <opencv2/ml/ml.hpp>
#include <fstream>
#include <string>
#include <queue>
extern"C"
{
#include <f2c.h>
#include <clapack.h>
};
#define _PADDING 10
using namespace std;
using namespace cv;
//inline double Search_in_Tabel(double sigma,double weight)
//{
//	return exp(-weight/sigma);
//}
double *** allocd_3(int n,int r,int c,int padding=_PADDING)
{
	double *a,**p,***pp;
	int rc=r*c;
	int i,j;
	a=(double*) malloc(sizeof(double)*(n*rc+padding));
	if(a==NULL) {printf("allocd_3() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(double**) malloc(sizeof(double*)*n*r);
	pp=(double***) malloc(sizeof(double**)*n);
	for(i=0;i<n;i++) 
		for(j=0;j<r;j++) 
			p[i*r+j]=&a[i*rc+j*c];
	for(i=0;i<n;i++) 
		pp[i]=&p[i*r];
	return(pp);
}
void freed_3(double ***p)
{
	if(p!=NULL)
	{
		free(p[0][0]);
		free(p[0]);
		free(p);
		p=NULL;
	}
}
float ** allocf_2(int r,int c,int padding=_PADDING)
{
	float *a,**p;
	a=(float*) malloc(sizeof(float)*(r*c+padding));
	if(a==NULL) {printf("allocf_2() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(float**) malloc(sizeof(float*)*r);

	for(int i=0;i<r;i++) 
		p[i]=&a[i*c];

	return(p);
}
void freef_2(float **p)
{
	if(p!=NULL)
	{
		free(p[0]);
		free(p);
		p=NULL;
	}
}
int ** alloci_2(int r,int c,int padding=_PADDING)
{
	int *a,**p;
	a=(int*) malloc(sizeof(int)*(r*c+padding));
	if(a==NULL) {printf("alloci_2() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(int**) malloc(sizeof(int*)*r);

	for(int i=0;i<r;i++) 
		p[i]=&a[i*c];

	return(p);
}
void freei_2(int **p)
{
	if(p!=NULL)
	{
		free(p[0]);
		free(p);
		p=NULL;
	}
}
double ** allocd_2(int r,int c,int padding=_PADDING)
{
	double *a,**p;
	a=(double*) malloc(sizeof(double)*(r*c+padding));
	if(a==NULL) {printf("allocd_2() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(double**) malloc(sizeof(double*)*r);

	for(int i=0;i<r;i++) 
		p[i]=&a[i*c];

	return(p);
}
void freed_2(double **p)
{
	if(p!=NULL)
	{
		free(p[0]);
		free(p);
		p=NULL;
	}
}




PCA compressPCA(InputArray pcaset, int maxComponents,
	const Mat& testset, OutputArray compressed)
{
	PCA pca(pcaset, // pass the data
		Mat(), // there is no pre-computed mean vector,
		// so let the PCA engine to compute it
		CV_PCA_DATA_AS_ROW, // indicate that the vectors
		// are stored as matrix rows
		// (use CV_PCA_DATA_AS_COL if the vectors are
		// the matrix columns)
		maxComponents // specify how many principal components to retain
		);
	// if there is no test data, just return the computed basis, ready-to-use
	if( !testset.data )
		return pca;
	CV_Assert( testset.cols == pcaset.size().width );

	compressed.create(testset.rows, maxComponents, testset.type());

	Mat reconstructed;
	for( int i = 0; i < testset.rows; i++ )
	{
		Mat vec = testset.row(i), coeffs = compressed.getMat(i);
		// compress the vector, the result will be stored
		// in the i-th row of the output matrix
		pca.project(vec, coeffs);
		// and then reconstruct it
		//pca.backProject(coeffs, reconstructed);
		//// and measure the error
		//printf("%d. diff = %g\n", i, norm(vec, reconstructed, NORM_L2));
	}
	return pca;
}
vector<Mat> showPCA(int m,int n,int channel,double ***img,Mat lab )
{
	
	Mat compress;
	Mat imgreshape((m*n),channel,CV_32FC1,Scalar(0.f));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<channel;k++)
			{
				imgreshape.at<float>(i*n+j,k)=(float)img[k][i][j];
			}
		}
	}
	if(!lab.data)
	{
		compressPCA(imgreshape,3,imgreshape,compress);
	}
	else
		compressPCA(lab,3,imgreshape,compress);
	vector<double> maxvalue(3),minvalue(3);
	for(int i=0;i<3;i++)
	    minMaxLoc(compress.col(i),&minvalue[i],&maxvalue[i]);

	Mat showpca(m,n,CV_8UC3,Scalar(0,0,0));
	vector<Mat> out;
	for(int i=0;i<3;i++)
	   out.push_back(Mat(m,n,CV_64FC1,Scalar(0.0)));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			unsigned R=unsigned((int)(255.f*(compress.at<float>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
			unsigned B=unsigned((int)(255.f*(compress.at<float>(i*n+j,1)-minvalue[1])/maxvalue[1]+0.5));
			unsigned G=unsigned((int)(255.f*(compress.at<float>(i*n+j,2)-minvalue[2])/maxvalue[2]+0.5));

			showpca.at<Vec3b>(i,j)=Vec3b(R,G,B);
			out[0].at<double>(i,j)=((double)compress.at<float>(i*n+j,0)-minvalue[0])/maxvalue[0];
			out[1].at<double>(i,j)=((double)compress.at<float>(i*n+j,0)-minvalue[0])/maxvalue[0];
			out[2].at<double>(i,j)=((double)compress.at<float>(i*n+j,0)-minvalue[0])/maxvalue[0];
		}
	}
	imshow("PCA",showpca);
	imwrite("PCA_all.png",showpca);
	waitKey();
	return out;
}
Mat LDA_(Mat inputm,Mat responses,int class_num,int choose_num)
{
	int num=inputm.rows;
	int bands=inputm.cols;
	CV_Assert(num==responses.rows);
	Mat within_class(bands,bands,CV_32FC1,Scalar(0.f));
	//vector<Mat> classMat_list(class_num);
	vector<vector<int>> index(class_num);

	for(int i=0;i<num;i++)
	{
		int lab=(int)responses.at<float>(i,0);
		index[lab-1].push_back(i);
	}
	Mat mean_temp(class_num,bands,CV_32FC1,Scalar(0.f));
	for(int i=0;i<class_num;i++)
	{
		int num_cur_class=(int)index[i].size();
		Mat temp(num_cur_class,bands,CV_32FC1,Scalar(0.f));	
		for(int j=0;j<num_cur_class;j++)
		{
			int ind=index[i][j];
			for(int k=0;k<bands;k++)
			{
				temp.at<float>(j,k)=inputm.at<float>(ind,k);
				mean_temp.at<float>(i,k)+=inputm.at<float>(ind,k);
			}
		}
		for(int k=0;k<bands;k++)
		{
			mean_temp.at<float>(i,k)/=(float)num_cur_class;
		}
		for(int j=0;j<num_cur_class;j++)
		{
			for(int k=0;k<bands;k++)
			{
				temp.at<float>(j,k)=temp.at<float>(j,k)-mean_temp.at<float>(i,k);
			}
		}
		within_class+=temp.t()*temp;
	}
	/////////////////////
	Mat mean_temp_all(1,bands,CV_32FC1,Scalar(0.f));
	for(int i=0;i<class_num;i++)
	{
		for(int k=0;k<bands;k++)
		{
			mean_temp_all.at<float>(0,k)+=mean_temp.at<float>(i,k)*(float(index[i].size()));
		}
	}
	mean_temp_all/=float(num);
	Mat between_class(bands,bands,CV_32FC1,Scalar(0.f));
	for(int i=0;i<class_num;i++)
	{
		for(int k=0;k<bands;k++)
		{
			mean_temp.at<float>(i,k)-=mean_temp_all.at<float>(0,k);
		}
		Mat temp2=mean_temp.row(i).clone();
		between_class+=(temp2.t()*temp2)*((float)index[i].size());
	}
	Mat Sw_inv_SB=(within_class.inv(0)*between_class);
	Mat eigenValue,eigenvector;
	if(!eigen(Sw_inv_SB,eigenValue,eigenvector))
	{
		cout<<"cannot eigen the matrix"<<endl;
		exit(0);
	}

	Mat out=eigenvector(Range(0,choose_num),Range(0,bands)).clone();
	return out;
}
vector<Mat> show_LDA(int m,int n,Mat inputm,Mat responses,int class_num,int choose_num,double ***img,int op=0)
{
	int channel=inputm.cols;
	Mat imgreshape((m*n),channel,CV_64FC1,Scalar(0.f));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<channel;k++)
			{
				imgreshape.at<double>(i*n+j,k)=img[k][i][j];
			}
		}
	}
	Mat compress;
	if(op)
	{
		Mat trans_Mat=LDA_(inputm,responses,class_num,choose_num);
		compress=imgreshape*trans_Mat.t();
	}
	else
	{
		LDA lda(inputm,responses,0);
		Mat eigenvalues=lda.eigenvalues();
		cout<<eigenvalues<<endl;
		double alleigen=sum(eigenvalues).val[0];
		int ii=0;
		double sumpercent=eigenvalues.at<double>(0,ii)/alleigen;
		while(sumpercent<0.96)
		{
			ii++;
			sumpercent+=eigenvalues.at<double>(0,ii)/alleigen;
		}
		choose_num=ii+1;
		choose_num=max(choose_num,3);
		Mat eigenvec=lda.eigenvectors();
		Mat lda_eigenvec=eigenvec(Range(0,eigenvec.rows),Range(0,choose_num));

		compress=imgreshape*lda_eigenvec;

	}	
	
	double *maxvalue=new double [choose_num];
	double *minvalue=new double [choose_num];
	for(int i=0;i<choose_num;i++)
	{
		minMaxLoc(compress.col(i),&minvalue[i],&maxvalue[i]);
	}

	//FileStorage fs;
	//fs.open("Mask.xml",FileStorage::READ);
	//Mat Mask;
	//fs["Mask"]>>Mask;
	//fs.release();

	Mat showlda(m,n,CV_8UC3,Scalar(0,0,0));
	vector<Mat> out;
	for(int i=0;i<choose_num;i++)
		out.push_back(Mat(m,n,CV_64FC1,Scalar(0.0)));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(op)
			{
				unsigned R,G,B;
				if(choose_num>=3)
				{
					R=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
					G=unsigned((int)(255.f*(compress.at<double>(i*n+j,1)-minvalue[1])/maxvalue[1]+0.5));
					B=unsigned((int)(255.f*(compress.at<double>(i*n+j,2)-minvalue[2])/maxvalue[2]+0.5));
				}
				else
				{
					R=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
					G=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
					B=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
				}

				showlda.at<Vec3b>(i,j)=Vec3b(R,G,B);
			
				for(int k=0;k<choose_num;k++)
				    out[k].at<double>(i,j)=(double)(compress.at<double>(i*n+j,k)-minvalue[k])/maxvalue[k];//(double)compress.at<float>(i*n+j,k);
				
			}
			else
			{
				unsigned R,G,B;
				if(choose_num>=3)
				{
					R=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
					G=unsigned((int)(255.f*(compress.at<double>(i*n+j,1)-minvalue[1])/maxvalue[1]+0.5));
					B=unsigned((int)(255.f*(compress.at<double>(i*n+j,2)-minvalue[2])/maxvalue[2]+0.5));
				}
				else
				{
					R=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
					G=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
					B=unsigned((int)(255.f*(compress.at<double>(i*n+j,0)-minvalue[0])/maxvalue[0]+0.5));
				}

				showlda.at<Vec3b>(i,j)=Vec3b(R,G,B);
				for(int k=0;k<choose_num;k++)
					out[k].at<double>(i,j)=(double)(compress.at<double>(i*n+j,k)-minvalue[k])/maxvalue[k];//(double)compress.at<double>(i*n+j,k);
			}
		}
	}
	vector<Mat> out2;
	
	for(int k=0;k<choose_num;k++)
	{
		Mat temp(m,n,CV_32FC1,Scalar(0.f));
		for(int i=0;i<m;i++)
			for(int j=0;j<n;j++)
			{
				temp.at<float>(i,j)=(float)out[k].at<double>(i,j);
			}
		out2.push_back(temp);
	}
	for(int k=0;k<choose_num;k++)
	    medianBlur(out2[k],out2[k],3);

	for(int k=0;k<choose_num;k++)
	{
		for(int i=0;i<m;i++)
			for(int j=0;j<n;j++)
			{
				out[k].at<double>(i,j)=out2[k].at<float>(i,j);
			}				
	}

	imshow("LDA",showlda);
	imwrite("LDA2_all.png",showlda);
	waitKey();
	delete[]maxvalue;
	maxvalue=NULL;
	delete[]minvalue;
	minvalue=NULL;
	return out;
}
Mat LDA_trans(Mat inputm,Mat responses,int choose_num)
{
	LDA lda(inputm,responses,0);
	Mat eigenvalues=lda.eigenvalues();
	//cout<<eigenvalues<<endl;
	double alleigen=sum(eigenvalues).val[0];
	int ii=0;
	double sumpercent=eigenvalues.at<double>(0,ii)/alleigen;
	while(sumpercent<0.96)
	{
		ii++;
		sumpercent+=eigenvalues.at<double>(0,ii)/alleigen;
	}
	choose_num=ii+1;
	choose_num=max(choose_num,3);
	Mat eigenvec=lda.eigenvectors();
	Mat lda_eigenvec=eigenvec(Range(0,eigenvec.rows),Range(0,choose_num));

	return lda_eigenvec;
}
bool lapack_eig(Mat A,Mat& eigen_vector,Mat& eigenval)
{
	integer N=A.cols;
	int n=A.cols;
	if(A.cols!=A.rows)
	{
		cout<<"error"<<endl;
		return false;
	}
	char JOBVT='V';
	char uplo='L';
	integer Lda=N;
	doublereal *AT=new doublereal[N*N];
	doublereal *w=new doublereal[N];
	doublereal *work=new doublereal[4*N];
	integer   LWORK=4*n,INFO;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			AT[j*n+i]=A.at<double>(i,j);
		}
	}
	dsyev_(&JOBVT,&uplo,&N,AT,&N,w,work,&LWORK,&INFO);
	if(INFO==0)
	{
		vector<int> idx;
		for(int i=0;i<N;i++)
		{
			if(w[i]>1e-6)
			{
				idx.push_back(i);
			}
		}
		eigenval=Mat(1,(int)idx.size(),CV_64FC1,Scalar(0,0));
		eigen_vector=Mat::zeros(N,(int)idx.size(),CV_64FC1);
		for(int i=0;i<(int)idx.size();i++)
		{
			int index=idx[i];
			eigenval.at<double>(0,i)=w[index];
			for(int j=0;j<N;j++)
			{
				eigen_vector.at<double>(j,i)=AT[index*N+j];
			}
		}
		flip(eigenval,eigenval,1);
		flip(eigen_vector,eigen_vector,1);
		delete[]AT;AT=NULL;
		delete[]w;w=NULL;
		delete[]work;work=NULL;
		return true;
	}
	else
	{
		delete[]AT;AT=NULL;
		delete[]w;w=NULL;
		delete[]work;work=NULL;
		return false;
	}
}

bool general_eig(Mat A,Mat B,Mat& eigen_vector,Mat& eigenval)  
{  
	integer N=A.cols;
	int n=A.cols;
	if (B.cols!= A.cols  || A.rows!=A.cols || B.rows!=A.cols)
		return false;
	eigen_vector=Mat::zeros(N,N,CV_64FC1);
	eigenval=Mat::zeros(1,N,CV_64FC1);
	integer itype=1;
	char JOBVT='V';
	char uplo='L';
	doublereal *AT=new doublereal[n*n];
	doublereal *BT=new doublereal[n*n];
	doublereal *w=new doublereal[n];
	doublereal *work=new doublereal[4*n];
	integer   LWORK=4*n,INFO;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			AT[j*n+i]=A.at<double>(i,j);
			BT[j*n+i]=B.at<double>(i,j);
		}
	}
	integer Lda=N;
	integer Ldb=N;

	dsygv_(&itype,&JOBVT,&uplo,&N,AT,&Lda,BT,&Ldb,w,work,&LWORK,&INFO);
	if(INFO==0)
	{
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
				eigen_vector.at<double>(i,j)=AT[j*N+i];
		}
		for(int i=0;i<N;i++)
			eigenval.at<double>(0,i)=w[i];
		delete[]AT;AT=NULL;
		delete[]BT;BT=NULL;
		delete[]w;w=NULL;
		delete[]work;work=NULL;
		//cout<<eigen_vector<<endl;
		//cout<<eigenval<<endl;

		return true;	
	}
	else
	{

		delete[]AT;AT=NULL;
		delete[]BT;BT=NULL;
		delete[]w;w=NULL;
		delete[]work;work=NULL;
		return false;
	}

}  
void Max_heapify(double* a,int *order,int N,int i)
{
	int l=2*(i+1)-1;
	int r=2*(i+1);
	int largest;
	if(l<N&&a[l]>a[i])
	{
		largest=l;
	}
	else
		largest=i;
	if(r<N&&a[r]>a[largest])
		largest=r;
	if(largest!=i)
	{
		double temp=a[i];
		a[i]=a[largest];
		a[largest]=temp;
		double temp2=order[i];
		order[i]=order[largest];
		order[largest]=temp2;
		Max_heapify(a,order,N,largest);
	}

}
void Bulid_Max_heap(double* a,int*order,int N)
{
	for(int i=N/2-1;i>=0;i--)
	{
		Max_heapify(a,order,N,i);
	}
}
vector<int> heap_sort(double*a,int N,int K)
{
	int *order=new int[N];
	for(int i=0;i<N;i++)
		order[i]=i;
	Bulid_Max_heap(a,order,N);
	int length_a=N;
	int ii=0;
	while(ii<K)
	{
		double temp=a[0];
		a[0]=a[length_a-1];
		a[length_a-1]=temp;
		double temp2=order[0];
		order[0]=order[length_a-1];
		order[length_a-1]=temp2;
		length_a--;
		ii++;
		Max_heapify(a,order,N-ii,0);		
	}
	vector<int>out(K);
	for(int i=0;i<K;i++)
		out[i]=order[N-1-i];
	delete[]order;
	order=NULL;
	return out;
}
Mat SELF(Mat train,Mat lab,Mat test,double beta,double r,int K=7)
{
	int num_train=train.rows;
	int num_test=test.rows;
	if(train.cols!=test.cols||num_train!=lab.rows)
	{
		cout<<"error��training-set 's dimension isn't equal to tests' "<<endl;
		return Mat();
	}
	int channel=train.cols;
	double minlab,maxlab;
	minMaxLoc(lab,&minlab,&maxlab);
	int class_num=int(maxlab-minlab+1);
	vector<vector<int>> id(class_num);
	for(int i=0;i<num_train;i++)
	{
		int labels=(int)lab.at<int>(i,0);
		id[labels-1].push_back(i);
	}
	///////////////	
	double *sigma=new double[num_train];
	//int numall=num_train+num_test;
	double **dist2=new double*[num_train];
	for(int i=0;i<num_train;i++)
		dist2[i]=new double[num_train-i];

	for(int i=0;i<num_train;i++)
	{
		for(int j=i;j<num_train;j++)
		{
			double temp=0.0;
			for(int k=0;k<channel;k++)
				temp+=pow((train.at<double>(i,k)-train.at<double>(j,k)),2);
			dist2[i][j-i]=temp;
		}
	}
	double *temp=new double[num_train];
	for(int i=0;i<num_train;i++)
	{		
		for(int j=i;j<num_train;j++)
			temp[j]=-dist2[i][j-i];
		for(int j=0;j<i;j++)
			temp[j]=-dist2[j][i-j];
		vector<int>order_id=heap_sort(temp,num_train,K+1);
		int id=order_id[K];
		sigma[i]=-temp[id];
		int dd=0;
		while(sigma[i]==0)
		{
			dd++;
			vector<int>order_id2=heap_sort(temp,num_train,K+1+dd);
			int id0=order_id2[K];
			sigma[i]=-temp[id0];
		}
	}
	delete[]temp;
	temp=NULL;
	//for(int i=0;i<num_train;i++)
	//{
	//	if(sigma[i]==0)
	//		cout<<i<<endl;
	//}
	Mat Wlb(num_train,num_train,CV_64FC1,Scalar(0));
	Mat Wlw(num_train,num_train,CV_64FC1,Scalar(0));
	for(int i=0;i<num_train;i++)
	{
		for(int j=i;j<num_train;j++)
		{
			if(lab.at<int>(i,0)==lab.at<int>(j,0))
			{
				int idx=(int)id[(int)lab.at<int>(i,0)-1].size();
				double A_ij=exp(-dist2[i][j-i]/sqrt(sigma[j]*sigma[i]));
				Wlb.at<double>(i,j)=A_ij*(1.0/(double)num_train-1.0/(double)idx);
				Wlb.at<double>(j,i)=Wlb.at<double>(i,j);
				Wlw.at<double>(i,j)=A_ij/(double)idx;
				Wlw.at<double>(j,i)=Wlw.at<double>(i,j);
			}
			else
			{
				Wlb.at<double>(i,j)=1.0/num_train;
				Wlb.at<double>(j,i)=Wlb.at<double>(i,j);
				Wlw.at<double>(i,j)=0.0;
				Wlw.at<double>(j,i)=0.0;
			}
		}
	}
	delete[]sigma;
	sigma=NULL;
	for(int i=0;i<num_train;i++)
	{
		delete[]dist2[i];
		dist2[i]=NULL;
	}
	delete[]dist2;
	dist2=NULL;
	Mat Llb(num_train,num_train,CV_64FC1,Scalar(0.0));
	Mat Llw(num_train,num_train,CV_64FC1,Scalar(0.0));
	for(int i=0;i<num_train;i++)
	{
		for(int j=0;j<num_train;j++)
		{
			Llw.at<double>(i,i)+=Wlw.at<double>(i,j);
			Llb.at<double>(i,i)+=Wlb.at<double>(i,j);
		}
	}
	Llb=Llb-Wlb;
	Llw=Llw-Wlw;
	
	//double minv,maxv;
	//Point2i minp,maxp;
	//minMaxLoc(Llb,&minv,&maxv,&minp,&maxp);
	//cout<<minv<<endl;
	//cout<<maxv<<endl;
	//cout<<minp<<endl;
	//cout<<maxp<<endl;
	//minMaxLoc(Llw,&minv,&maxv,&minp,&maxp);
	//cout<<minv<<endl;
	//cout<<maxv<<endl;
	//cout<<minp<<endl;
	//cout<<maxp<<endl;
	//minMaxLoc(train,&minv,&maxv,&minp,&maxp);
	//cout<<minv<<endl;
	//cout<<maxv<<endl;
	//cout<<minp<<endl;
	//cout<<maxp<<endl;
	Mat temp111=train.t()*Llb;
	//cout<<temp111.row(0)<<endl;
	Mat Slb=train.t()*Llb*train;
	Mat Slw=train.t()*Llw*train;

	Mat X(channel,num_train+num_test,CV_64FC1,Scalar(0));
	for(int i=0;i<num_train;i++)
	{
		for(int j=0;j<channel;j++)
			X.at<double>(j,i)=train.at<double>(i,j);
	}
	for(int i=0;i<num_test;i++)
	{
		for(int j=0;j<channel;j++)
			X.at<double>(j,i+num_train)=test.at<double>(i,j);
	}
	Mat mean_X(channel,1,CV_64FC1,Scalar(0));
	for(int i=0;i<channel;i++)
	{
		double temp=0;
		for(int j=0;j<num_train+num_test;j++)
			temp+=X.at<double>(i,j);
		temp/=(num_train+num_test);
		mean_X.at<double>(i,0)=temp;
	}
	Mat St=X*X.t()-(num_train+num_test)*mean_X*mean_X.t();
	Mat S_rlw=(1.0-beta)*Slw+beta*Mat::eye(channel,channel,CV_64FC1);
	//cout<<Mat::eye(5,5,CV_64FC1)<<endl;//S_rlw(Range(91,101),Range(91,101))
	double ispostivedefine=determinant(S_rlw);
	while(ispostivedefine<1e-8)
	{
		beta=beta+0.01;
		S_rlw=(1.0-beta)*Slw+beta*Mat::eye(channel,channel,CV_64FC1);
		ispostivedefine=determinant(S_rlw);
	}
	Mat S_rlb=(1.0-beta)*Slb+beta*St;
	S_rlw=(1.0-beta)*Slw+beta*Mat::eye(channel,channel,CV_64FC1);
	//cout<<S_rlw<<endl;
	Mat eigenvalue,eigenvector;
	if(general_eig(S_rlb,S_rlw,eigenvector,eigenvalue))
	{
		int choose_num;
		if(r>=1)
		{
			choose_num=(int)r;
		}
		else
		{
			double sum_temp=1.0/(sum(eigenvalue).val[0]);
			//cout<<eigenvalue<<endl;
			int k=channel-1;
			double temp=eigenvalue.at<double>(0,k);

			while(temp*sum_temp<r&&k>=0)
			{
				k--;
				temp+=eigenvalue.at<double>(0,k);
			}
			choose_num=channel-k;
		}
		//cout<<eigenvector.rows<<endl;
		//cout<<eigenvector.cols<<endl;
		//cout<<choose_num<<endl;
		//cout<<channel<<endl;
		Mat T=eigenvector(Range(0,channel),Range(channel-choose_num,channel));
		for(int i=0;i<choose_num;i++)
		{
			double scale=sqrt(eigenvalue.at<double>(0,channel-choose_num+i));
			for(int j=0;j<channel;j++)
				T.at<double>(j,i)*=scale;
		}	
		flip(T,T,1);
		return T;
	}
	else
	{
		Mat sbeigval,sbeigvec;
		lapack_eig(S_rlw,sbeigvec,sbeigval);
		int rr=sbeigval.cols;
		Mat temp0(rr,rr,CV_64FC1,Scalar(0));
		for(int i=0;i<rr;i++)
		{
			temp0.at<double>(i,i)=1.0/sqrt(sbeigval.at<double>(0,i));
		}
		Mat temp1=temp0*(sbeigvec.t())*S_rlb*sbeigvec*temp0;
		Mat sbeigval2,sbeigvec2;
		lapack_eig(temp1,sbeigvec2,sbeigval2);
		Mat temp3=sbeigvec*temp0*sbeigvec2;
		int choose_num;
		if(r>1)
		{
			choose_num=(temp3.cols>r ? r:temp3.cols);
		}
		else
		{
			choose_num=(temp3.cols>10 ? 10:temp3.cols);
		}
		return temp3(Range(0,channel),Range(0,choose_num));	
	}
}
vector<Mat> showimg_trans(Mat img,Mat W,int m,int n,Mat& show)
{
	if(img.cols!=W.rows)
	{
		cout<<"error"<<endl;
		waitKey();
		exit(0);
	}
	int channel=W.cols;
	Mat trans=img*W;
	show=Mat(m,n,CV_8UC3,Scalar(0));
	vector<Mat> out;
	for(int i=0;i<channel;i++)
	{
		Mat temp(m,n,CV_64FC1,Scalar(0));
		out.push_back(temp);
	}
	
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<channel;k++)
				out[k].at<double>(i,j)=trans.at<double>(i*n+j,k);
		}
	}
	double *minval=new double[3];
	double *maxval=new double[3];
	for(int i=0;i<3;i++)
	{
		minMaxLoc(out[i],&minval[i],&maxval[i]);
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			show.at<Vec3b>(i,j)[0]=(uchar)int(255.0*(out[0].at<double>(i,j)-minval[0])/maxval[0]+0.5);
			show.at<Vec3b>(i,j)[1]=(uchar)int(255.0*(out[1].at<double>(i,j)-minval[1])/maxval[1]+0.5);
			show.at<Vec3b>(i,j)[2]=(uchar)int(255.0*(out[2].at<double>(i,j)-minval[2])/maxval[2]+0.5);
		}
	}
	delete[]minval;minval=NULL;
	delete[]maxval;maxval=NULL;
	return out;
}
Mat Guidedfilter_color(vector<Mat> Guided_img,Mat src,int r,double eps)
{
	int channel=(int)Guided_img.size();
	//CV_Assert(channel==3);
	int m=src.rows;
	int n=src.cols;
	vector<Mat> mean_G(channel);
	for(int i=0;i<channel;i++)
	{
		boxFilter(Guided_img[i],mean_G[i],CV_64FC1,Size(r,r));
	}
	Mat mean_S;
	boxFilter(src,mean_S,CV_64FC1,Size(r,r));
	vector<Mat> mean_GS(channel);
	for(int i=0;i<channel;i++)
	{
		boxFilter(Guided_img[i].mul(src),mean_GS[i],CV_64FC1,Size(r,r));
	}
	vector<Mat> cov_GS(channel);
	for(int i=0;i<channel;i++)
	{
		cov_GS[i]=mean_GS[i]-mean_G[i].mul(mean_S);
	}
	vector<vector<Mat>> var(channel);
	for(int i=0;i<channel;i++)
	{
		for(int j=i;j<channel;j++)
		{
			Mat temp;
			boxFilter(Guided_img[i].mul(Guided_img[j]),temp,CV_64FC1,Size(r,r));
			temp-=mean_G[i].mul(mean_G[j]);
			var[i].push_back(temp);
		}
	}
	vector<Mat> a(channel);
	for(int i=0;i<channel;i++)
	{
		a[i]=Mat(m,n,CV_64FC1,Scalar(0.0));
	}
	for (int i =0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			Mat sigma(channel,channel,CV_64FC1,Scalar(0.0));
			for(int k1=0;k1<channel;k1++)
			{
				for(int k2=k1;k2<channel;k2++)
				{
					sigma.at<double>(k1,k2)=var[k1][k2-k1].at<double>(i,j);
				}
				for(int k2=0;k2<k1;k2++)
				{
					sigma.at<double>(k1,k2)=sigma.at<double>(k2,k1);
				}
			}
			Mat cov_Ip(1,channel,CV_64FC1,Scalar(0.0));
			for(int k=0;k<channel;k++)
			{
				cov_Ip.at<double>(0,k)=cov_GS[k].at<double>(i,j);
			}
			Mat eps_sigma=Mat::eye(channel,channel,CV_64F)*eps;
			eps_sigma+=sigma;
			Mat inv_eps_sigma;
			invert(eps_sigma,inv_eps_sigma,DECOMP_LU);
			Mat result=cov_Ip*inv_eps_sigma;
			for(int k=0;k<channel;k++)
			{
				a[k].at<double>(i,j)=result.at<double>(0,k);
			}
		}
	}

	Mat b=mean_S.clone();
	for(int i=0;i<channel;i++)
	{
		b-=(a[i].mul(mean_G[i]));
	}
	vector<Mat> af(channel);
	Mat bf;
	for(int i=0;i<channel;i++)
	{
		boxFilter(a[i],af[i],CV_64FC1,Size(r,r));
	}
	boxFilter(b,bf,CV_64FC1,Size(r,r));
	Mat out=bf.clone();
	for(int i=0;i<channel;i++)
	{
		out+=af[i].mul(Guided_img[i]);
	}
    return   out;
}
////////////////////////// i want to implement with gpu but opencv-gpu boxfilter only support uchar8-channel1 or 4 type,so.... 
//struct BufferGF
//{
//	gpu::GpuMat gG1,gG2,gG3,gS,
//		        mean_G1,mean_G2,mean_G3,mean_S,
//				mean_G1S,mean_G2S,mean_G3S,
//				cov_G1S,cov_G2S,cov_G3S,
//				var_G11,var_G12,var_G13,
//				        var_G22,var_G23,
//						        var_G33,
//			  multemp1,multemp2,multemp3,multemp4,multemp5,multemp6,
//			  sigma,
//			  a1,a2,a3,b;
//
//};
//Mat Guidedfilter_color(vector<Mat> Guided_img,Mat src,int r,float eps,BufferGF &b)
//{
//	
//	int channel=(int)Guided_img.size();
//	CV_Assert(channel==3);
//	b.gG1.upload(Guided_img[0]);
//	b.gG2.upload(Guided_img[1]);
//	b.gG3.upload(Guided_img[2]);
//	b.gS.upload(src);
//	int m=src.rows;
//	int n=src.cols;
//	gpu::Stream stream;
//	gpu::boxFilter(b.gG1,b.mean_G1,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::boxFilter(b.gG2,b.mean_G2,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::boxFilter(b.gG3,b.mean_G3,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::boxFilter(b.gS,b.mean_S,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG1,b.gS,b.multemp1,1,-1,stream);
//	gpu::boxFilter(b.multemp1,b.mean_G1S,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG2,b.gS,b.multemp2,1,-1,stream);
//	gpu::boxFilter(b.multemp2,b.mean_G2S,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG3,b.gS,b.multemp3,1,-1,stream);
//	gpu::boxFilter(b.multemp3,b.mean_G3S,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	stream.waitForCompletion();/////////////////////
//	gpu::multiply(b.mean_G1,b.mean_S,b.multemp1,1,-1,stream);
//	gpu::subtract(b.mean_G1S,b.multemp1,b.cov_G1S,gpu::GpuMat(),-1,stream);
//	gpu::multiply(b.mean_G2,b.mean_S,b.multemp2,1,-1,stream);
//	gpu::subtract(b.mean_G2S,b.multemp2,b.cov_G2S,gpu::GpuMat(),-1,stream);
//	gpu::multiply(b.mean_G3,b.mean_S,b.multemp3,1,-1,stream);
//	gpu::subtract(b.mean_G3S,b.multemp3,b.cov_G3S,gpu::GpuMat(),-1,stream);
//	stream.waitForCompletion();/////////////////////
//	gpu::multiply(b.gG1,b.gG1,b.multemp1,1,-1,stream);
//	gpu::boxFilter(b.multemp1,b.var_G11,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG1,b.gG2,b.multemp2,1,-1,stream);
//	gpu::boxFilter(b.multemp2,b.var_G12,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG1,b.gG3,b.multemp3,1,-1,stream);
//	gpu::boxFilter(b.multemp3,b.var_G13,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG2,b.gG2,b.multemp4,1,-1,stream);
//	gpu::boxFilter(b.multemp4,b.var_G22,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG2,b.gG3,b.multemp5,1,-1,stream);
//	gpu::boxFilter(b.multemp5,b.var_G23,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	gpu::multiply(b.gG3,b.gG3,b.multemp6,1,-1,stream);
//	gpu::boxFilter(b.multemp6,b.var_G33,CV_32FC1,Size(r,r),Point(-1,-1),stream);
//	stream.waitForCompletion();////////////////
//	Mat var11,var12,var13,var22,var23,var33;
//	b.var_G11.download(var11);
//	b.var_G12.download(var12);
//	b.var_G13.download(var13);
//	b.var_G22.download(var22);
//	b.var_G23.download(var23);
//	b.var_G33.download(var33);
//	Mat cov1p,cov2p,cov3p;
//	b.cov_G1S.download(cov1p);
//	b.cov_G2S.download(cov2p);
//	b.cov_G3S.download(cov3p);
//	Mat a1(m,n,CV_32FC1,Scalar(0));
//	Mat a2(m,n,CV_32FC1,Scalar(0));
//	Mat a3(m,n,CV_32FC1,Scalar(0));
//	for (int i =0;i<m;i++)
//	{
//		for(int j=0;j<n;j++)
//		{
//			Mat sigma=(Mat_<float>(3,3)<<var11.at<float>(i,j),var12.at<float>(i,j),var13.at<float>(i,j),
//						var12.at<float>(i,j),var22.at<float>(i,j),var23.at<float>(i,j),
//						var13.at<float>(i,j),var23.at<float>(i,j),var33.at<float>(i,j));
//
//
//			Mat cov_Ip=(Mat_<float>(1,3)<<cov1p.at<float>(i,j),cov2p.at<float>(i,j),cov3p.at<float>(i,j));
//			Mat eps_sigma=Mat::eye(3,3,CV_64F)*eps;
//			eps_sigma+=sigma;
//			Mat inv_eps_sigma;
//			invert(eps_sigma,inv_eps_sigma,DECOMP_LU);
//			Mat result=cov_Ip*inv_eps_sigma;
//			a1.at<float>(i,j)=result.at<float>(0,0);
//			a2.at<float>(i,j)=result.at<float>(0,1);
//			a3.at<float>(i,j)=result.at<float>(0,2);
//		}
//	}
//	Mat mean_p,mean_I1,mean_I2,mean_I3;
//	b.mean_S.download(mean_p);
//	b.mean_G1.download(mean_I1);
//	b.mean_G2.download(mean_I2);
//	b.mean_G3.download(mean_I3);
//	Mat b0=mean_p-a1.mul(mean_I1)-a2.mul(mean_I2)-a3.mul(mean_I3);
//
//	Mat a1b,a2b,a3b,br;
//	boxFilter(a1,a1b,CV_64FC1,Size(r,r));
//	boxFilter(a2,a2b,CV_64FC1,Size(r,r));
//	boxFilter(a3,a3b,CV_64FC1,Size(r,r));
//	boxFilter(b0,br,CV_64FC1,Size(r,r));
//	Mat q=(a1b.mul(Guided_img[0])+a2b.mul(Guided_img[1])+a3b.mul(Guided_img[2])+br);
//	return q;
//}



double Accury_Evalution(vector<Point3i>Testlist,int maxnum_class,Mat stat_eval,bool verbose=0,const char *filename=NULL)
{
	int testnum=(int)Testlist.size();
	Mat confuse_Matrix(maxnum_class,maxnum_class,CV_32SC1,Scalar(0));
	for(int i=0;i<testnum;i++)
	{
		int gtlab=Testlist[i].z;	
		int userlab=stat_eval.at<int>(Testlist[i].x,Testlist[i].y);
		confuse_Matrix.at<int>(userlab-1,gtlab-1)+=1;	
	
	}
	int sum_correct=0;
	for(int i=0;i<maxnum_class;i++)
	{
		sum_correct+=confuse_Matrix.at<int>(i,i);
	}
	
	double OA=(double)sum_correct/(double)testnum;
	if(verbose)
	{
		Mat chart_accuracy(1,maxnum_class,CV_64FC1,Scalar(0.0));
		Mat user_accuracy(1,maxnum_class,CV_64FC1,Scalar(0.0));
		double xout_outx=0.0;
		for(int i=0;i<maxnum_class;i++)
		{
			double num=(double)confuse_Matrix.at<int>(i,i);
			double sum_col=(sum(confuse_Matrix.col(i))).val[0];
			double sum_row=(sum(confuse_Matrix.row(i))).val[0];
			if(sum_col==0||sum_row==0) continue;
			chart_accuracy.at<double>(0,i)=num/sum_col;
			user_accuracy.at<double>(0,i)=num/sum_row;
			xout_outx+=(sum_col*sum_row);
		}

		double Kappa=((double)sum_correct*testnum-xout_outx)/((double)testnum*testnum-xout_outx);
		double AA=mean(chart_accuracy).val[0];
	
		cout<<confuse_Matrix<<endl;
		cout<<"overall accuracy: "<<OA*100<<"%"<<endl;
		cout<<"average accuracy: "<<AA*100.0<<"%"<<endl;
		cout<<"Kappa: "<<Kappa<<endl;
		cout<<"producer's accuracy"<<chart_accuracy<<endl;
		cout<<"user's accuracy"<<user_accuracy<<endl;
		FileStorage fsa;
		fsa.open(filename,FileStorage::WRITE);
		fsa<<"overall_accuracy"<<OA*100;
		fsa<<"average_accuracy"<<AA*100;
		fsa<<"Kappa"<<Kappa;
		fsa<<"confuse_Matrix"<<confuse_Matrix;
		fsa<<"producer_accuracy"<<chart_accuracy;
		fsa<<"user_accuracy"<<user_accuracy;
		fsa.release();
	}	
	return OA;
}
////////////////////////////////////segments-tree
struct Seg_Tree
{
	vector<int>vex;
	vector<Vec2i>edge;
	int num_vex;
	int num_edge;
	double max_weight;
};
inline int findset(int x,int*parent)
{
	int parent_point=parent[x];
	if(x!=parent_point)
	{
		parent[x]=findset(parent_point,parent);
	}
	return parent[x];
}
double compute_distnace(vector<Mat> Guideimg,Point2i point1,Point point2,int op=1)
{
	double maxval=0.0;
	int channel=(int)Guideimg.size();
	if(op==1)//////////////L-infinity norm
	{
		Mat temp(1,channel,CV_64FC1,Scalar(0.0));
		for(int k=0;k<channel;k++)
		{
			temp.at<double>(0,k)=abs(Guideimg[k].at<double>(point1.x,point1.y)-Guideimg[k].at<double>(point2.x,point2.y));
		}		
		minMaxLoc(temp,NULL,&maxval);
	}
	else if(op==2)////////////////L1-norm
	{
		for(int k=0;k<channel;k++)
		{
			maxval+=abs(Guideimg[k].at<double>(point1.x,point1.y)-Guideimg[k].at<double>(point2.x,point2.y));
		}
	}
	else if(op==3)////////////////SAM ---compute angle between point 1 and point2
	{
		double numerator=0.0;
		double den1=0.0,den2=0.0;
		for(int k=0;k<channel;k++)
		{
			numerator+=Guideimg[k].at<double>(point1.x,point1.y)*Guideimg[k].at<double>(point2.x,point2.y);
			den1+=Guideimg[k].at<double>(point1.x,point1.y)*Guideimg[k].at<double>(point1.x,point1.y);
			den2+=Guideimg[k].at<double>(point2.x,point2.y)*Guideimg[k].at<double>(point2.x,point2.y);
		}
		double dddd=min(1.0,numerator/(sqrt(den1)*sqrt(den2)));			
		maxval=acos(dddd);
	}
	else//////////////////////// SID compute the discrpancy of probabilistic behaviors between point 1 and point2
	{
		double sum1=0.0,sum2=0.0;
		for(int k=0;k<channel;k++)
		{
			sum1+=Guideimg[k].at<double>(point1.x,point1.y);
			sum2+=Guideimg[k].at<double>(point2.x,point2.y);
		}
		Mat temp1(channel,1,CV_64FC1,Scalar(0.0));
		Mat temp2(channel,1,CV_64FC1,Scalar(0.0));
		if(sum1!=0)
		{
			for(int k=0;k<channel;k++)
				temp1.at<double>(k,0)=Guideimg[k].at<double>(point1.x,point1.y)/sum1;
		}
		if(sum2!=0)
		{
			for(int k=0;k<channel;k++)
			{
				temp2.at<double>(k,0)=Guideimg[k].at<double>(point2.x,point2.y)/sum2;
			}
		}
		
		for(int k=0;k<channel;k++)
		{
			double x1=(temp1.at<double>(k,0)>0 ? log(temp1.at<double>(k,0)):-1e10);
			double x2=(temp2.at<double>(k,0)>0 ? log(temp2.at<double>(k,0)):-1e10);
			maxval+=(temp1.at<double>(k,0)-temp2.at<double>(k,0))*(x1-x2);
		}	
	}
	return maxval;
}
void quicksort(int left,int right,double *a,int* index)
{
	int i,j,ind,ind2;
	double temp,t;
	if(left>right) return;
	i=left;
	j=right;
	temp=a[left];
	ind2=index[left];
	while(i!=j)
	{
		while(a[j]>=temp&&i<j)
			j--;
		while(a[i]<=temp&&i<j)
			i++;
		if(i<j)
		{
			t=a[i];
			a[i]=a[j];
			a[j]=t;

			ind=index[i];
			index[i]=index[j];
			index[j]=ind;
		}
	}
	a[left]=a[i];
	a[i]=temp;

	index[left]=index[i];
	index[i]=ind2;

	quicksort(left,i-1,a,index);
	quicksort(i+1,right,a,index);
}

void Segments_tree(vector<Mat> Guideimg,vector<int> &node_seq,vector<int> &nr_children_seq,
	vector<vector<int>> &children_seq,vector<int> &parent_seq,vector<double> &weight_seq)
{
	int m=Guideimg[0].rows;
	int n=Guideimg[0].cols;
	int channel=(int)Guideimg.size();
	int num_edge=(m-1)*n+(n-1)*m;
	int num_vertices=m*n;
	int**edge=alloci_2(num_edge,2);
	double *distance=new double[num_edge];
	double *distance_temp=new double[num_edge];
	double KK=0.0;

	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n-1;j++)
		{
			double maxval=compute_distnace(Guideimg,Point2i(i,j),Point2i(i,j+1),3);/////////////////////
			distance[i*(n-1)+j]=maxval;
			distance_temp[i*(n-1)+j]=maxval;
			KK+=(maxval*maxval);
			edge[i*(n-1)+j][0]=i*n+j;
			edge[i*(n-1)+j][1]=i*n+j+1;
		}
	}
	for(int j=0;j<n;j++)
	{
		for(int i=0;i<m-1;i++)
		{
			double maxval=compute_distnace(Guideimg,Point2i(i,j),Point2i(i+1,j),3);//////////////////////
			if(abs(maxval)>100000000)
				maxval=0;
			distance[m*(n-1)+j*(m-1)+i]=maxval;
			distance_temp[m*(n-1)+j*(m-1)+i]=maxval;
			KK+=(maxval*maxval);
			edge[m*(n-1)+j*(m-1)+i][0]=i*n+j;
			edge[m*(n-1)+j*(m-1)+i][1]=(i+1)*n+j;
		}		
	}
	
	cout<<"sigma: "<<sqrt(KK/double(m*(n-1)+n*(m-1)-1))<<endl;
	double K=sqrt(KK/double(m*(n-1)+n*(m-1)-1))*5;
	cout<<"K: "<<K<<endl;
	int* id_edge=new int[num_edge];
	for(int i=0;i<num_edge;i++)
		id_edge[i]=i;
	/*for(int i=0;i<num_edge;i++)
	{
		for(int j=0;j<num_edge-1-i;j++)
		{
			if(distance_temp[id_edge[j]]>distance_temp[id_edge[j+1]])
			{
				int temp=id_edge[j];
				id_edge[j]=id_edge[j+1];
				id_edge[j+1]=temp;
				double temp_dis=distance_temp[id_edge[j]];
				distance_temp[id_edge[j]]=distance_temp[id_edge[j+1]];
				distance_temp[id_edge[j+1]]=temp_dis;
			}
		}
	}*/
	quicksort(0,num_edge-1,distance_temp,id_edge);
	delete []distance_temp;
	distance_temp=NULL;
	vector<Seg_Tree> ST(num_vertices);
	for(int i=0;i<num_vertices;i++)
	{
		ST[i].vex.push_back(i);
		ST[i].num_vex=1;
		ST[i].num_edge=0;
		ST[i].max_weight=0.0;
	}
	int* parent=new int [num_vertices];
	int* nr_child=new int [num_vertices];
	double* weight= new double [num_vertices];
	int** children=alloci_2(num_vertices,4);
	double** connected_distance=allocd_2(num_vertices,4);
	int** connected=alloci_2(num_vertices,4);
	int* nr_connected=new int[num_vertices];
	memset(nr_connected,0,sizeof(int)*num_vertices);
	int* node_id=new int[num_vertices];
	int* rank=new int[num_vertices];
	queue<int> myqueue;

	for(int i=0;i<num_vertices;i++) 
	{	
		parent[i]=i;
		nr_connected[i]=0;
	}

	int tree_size=0;
	vector<int> edge_0;
	int nu=(int)(0.1*num_edge);

	for(int i=0;i<num_edge;i++)
	{
		if(i%nu==0) cout<<(i/nu)<<"0%"<<endl;
		int id=id_edge[i];
		int u=edge[id][0];
		int v=edge[id][1];		
		int pu=findset(u,parent);
		int pv=findset(v,parent);
		double wT=min(ST[pu].max_weight+(K/double(ST[pu].num_vex)),ST[pv].max_weight+(K/double(ST[pv].num_vex)));

		if((pu!=pv)&&(distance[id]<=wT))
		{
			int num_e=ST[pv].num_edge;
			for(int j=0;j<num_e;j++)
			{
				ST[pu].edge.push_back(ST[pv].edge[j]);
			}
			Vec2i e_current(u,v);
			ST[pu].edge.push_back(e_current);
			ST[pu].num_edge+=(ST[pv].num_edge+1);
			int num_v=ST[pv].num_vex;
			for(int j=0;j<num_v;j++)
			{
				ST[pu].vex.push_back(ST[pv].vex[j]);
			}
			ST[pu].num_vex+=num_v;
			ST[pu].max_weight=max(ST[pu].max_weight,max(ST[pv].max_weight,distance[id]));


			ST[pv].edge.clear();
			ST[pv].max_weight=-1;
			ST[pv].num_edge=-1;
			ST[pv].num_vex=-1;
			ST[pv].vex.clear();


			int num_connected=nr_connected[u];
			connected[u][num_connected]=v;
			connected_distance[u][num_connected]=distance[id];
			nr_connected[u]++;

			num_connected=nr_connected[v];
			connected[v][num_connected]=u;
			connected_distance[v][num_connected]=distance[id];
			nr_connected[v]++;

			tree_size++;
			parent[pv]=parent[pu];
		}
		else
		{
			edge_0.push_back(id);
		}
	}
	vector<Seg_Tree> ST0;	
	for(int i=0;i<num_vertices;i++)
	{
		if(ST[i].num_vex==-1)
			continue;
		else
			ST0.push_back(ST[i]);
	}
	cout<<"100%"<<endl;
	////////////////////////////////////////��ʾdisplay
	srand((unsigned)time(NULL));	
	Mat Temp(m,n,CV_8UC3,Scalar(0,0,0));
	for(int i=0;i<ST0.size();i++)
	{		
		if(ST0[i].num_vex==-1) continue;
		uchar R=(uchar)(int(256.0*rand()/(RAND_MAX+1.0)));
		uchar G=(uchar)(int(256.0*rand()/(RAND_MAX+1.0)));
		uchar B=(uchar)(int(256.0*rand()/(RAND_MAX+1.0)));
		for(int j=0;j<ST0[i].num_vex;j++)
		{
			int id0=ST0[i].vex[j];
			int x=id0/n;
			int y=id0%n;

			Temp.at<Vec3b>(x,y)=Vec3b(B,G,R);
		}	

	}
	imshow("1111",Temp);
	imwrite("seg.png",Temp);
	waitKey();
	///////////////
	for(int i=0;i<num_edge;i++)
	{
		if(i%nu==0) cout<<(i/nu)<<"0%"<<endl;
		int id=id_edge[i];
		int u=edge[id][0];
		int v=edge[id][1];		
		int pu=findset(u,parent);
		int pv=findset(v,parent);
		double minvex=min(double(ST[pu].num_vex),double(ST[pv].num_vex));

		if((pu!=pv)&&(minvex<=6)&&(minvex>0))
		{
			int num_e=ST[pv].num_edge;
			for(int j=0;j<num_e;j++)
			{
				ST[pu].edge.push_back(ST[pv].edge[j]);
			}
			Vec2i e_current(u,v);
			ST[pu].edge.push_back(e_current);
			ST[pu].num_edge+=(ST[pv].num_edge+1);
			int num_v=ST[pv].num_vex;
			for(int j=0;j<num_v;j++)
			{
				ST[pu].vex.push_back(ST[pv].vex[j]);
			}
			ST[pu].num_vex+=num_v;
			ST[pu].max_weight=max(ST[pu].max_weight,max(ST[pv].max_weight,distance[id]));


			ST[pv].edge.clear();
			ST[pv].max_weight=-1;
			ST[pv].num_edge=-1;
			ST[pv].num_vex=-1;
			ST[pv].vex.clear();


			int num_connected=nr_connected[u];
			connected[u][num_connected]=v;
			connected_distance[u][num_connected]=distance[id];
			nr_connected[u]++;

			num_connected=nr_connected[v];
			connected[v][num_connected]=u;
			connected_distance[v][num_connected]=distance[id];
			nr_connected[v]++;
			parent[pv]=parent[pu];
			tree_size++;
			for(vector<int>::iterator iter=edge_0.begin(); iter!=edge_0.end(); )
			{
				if(*iter==id)
					iter=edge_0.erase(iter);
				else
					iter++ ;
			}
			if(tree_size==num_vertices-1)
				break;			
		}
	}
	////////////////////////////
	vector<Seg_Tree> ST1;	
	for(int i=0;i<num_vertices;i++)
	{
		if(ST[i].num_vex==-1)
			continue;
		else
			ST1.push_back(ST[i]);
	}
	cout<<"100%"<<endl;
	////////////////////////////////////////��ʾdisplay
	srand((unsigned)time(NULL));	
	Mat Temp1(m,n,CV_8UC3,Scalar(0,0,0));
	for(int i=0;i<ST1.size();i++)
	{		
		if(ST1[i].num_vex==-1) continue;
		uchar R=(uchar)(int(256.0*rand()/(RAND_MAX+1.0)));
		uchar G=(uchar)(int(256.0*rand()/(RAND_MAX+1.0)));
		uchar B=(uchar)(int(256.0*rand()/(RAND_MAX+1.0)));
		for(int j=0;j<ST1[i].num_vex;j++)
		{
			int id0=ST1[i].vex[j];
			int x=id0/n;
			int y=id0%n;

			Temp1.at<Vec3b>(x,y)=Vec3b(B,G,R);
		}	

	}
	imshow("2222",Temp1);
	imwrite("seg_final.png",Temp1);
	waitKey();
	///////////////
	///////////////////////////

	int loop=0;
	int num_least_size=num_vertices-1-tree_size;
	for(int i=0;i<edge_0.size();i++)
	{		
		int id=edge_0[i];
		int u=edge[id][0];
		int v=edge[id][1];		
		int pu=findset(u,parent);
		int pv=findset(v,parent);
		if(pu!=pv)
		{
			/*try{*/			
			int num_e=ST[pv].num_edge;
			//cout<<"loop: "<<loop<<endl;
			//cout<<num_e<<endl;
			//cout<<ST[pv].num_edge<<endl;
			//cout<<ST[pv].num_vex<<endl;
			//cout<<ST[pu].num_edge<<endl;
			//cout<<ST[pu].num_vex<<endl;

			ST[pu].edge.resize(ST[pu].num_edge+num_e+1);
			//if(ST[pu].num_edge=0)
			//{
			for(int j=0;j<num_e;j++)
			{
				ST[pu].edge[ST[pu].num_edge+j]=ST[pv].edge[j];
			}
		//	}
			ST[pu].num_edge+=(num_e+1);
			Vec2i e_current(u,v);
			ST[pu].edge[ST[pu].num_edge-1]=e_current;

			int num_v=ST[pv].num_vex;
			ST[pu].vex.resize(ST[pu].num_vex+num_v);
			for(int j=0;j<num_v;j++)
			{
				ST[pu].vex[ST[pu].num_vex+j]=ST[pv].vex[j];
			}
			ST[pu].num_vex+=num_v;
			ST[pu].max_weight=max(ST[pu].max_weight,max(ST[pv].max_weight,distance[id]));			

			ST[pv].edge.clear();
			ST[pv].max_weight=-1;
			ST[pv].num_edge=-1;
			ST[pv].num_vex=-1;
			ST[pv].vex.clear();

			int num_connected=nr_connected[u];
			connected[u][num_connected]=v;
			connected_distance[u][num_connected]=distance[id];
			nr_connected[u]++;

			num_connected=nr_connected[v];
			connected[v][num_connected]=u;
			connected_distance[v][num_connected]=distance[id];
			nr_connected[v]++;
			if(loop%(int(num_least_size*0.1))==0)
				cout<<10*int((double)loop/(double)num_least_size*10+0.5)<<"%"<<endl;
			tree_size++;
			loop++;
			
			parent[pv]=parent[pu];
			if(tree_size==num_vertices-1)
				break;
		}
	}
	int tree_parent=0;
	int noed_parent=tree_parent;
	memset(parent,-1,sizeof(int)*num_vertices);
	memset(nr_child,0,sizeof(int)*num_vertices);
	memset(rank,0,sizeof(int)*num_vertices);
	parent[noed_parent]=noed_parent;
	weight[noed_parent]=0;
	node_id[0]=noed_parent;
	int len=1;
	myqueue.push(noed_parent);
	while(myqueue.size()>0)
	{
		noed_parent=myqueue.front();
		myqueue.pop();
		int num_nr_connected=nr_connected[noed_parent];
		for(int i=0;i<num_nr_connected;i++)
		{
			int potential_child=connected[noed_parent][i];
			if(parent[potential_child]==-1)
			{
				myqueue.push(potential_child);
				parent[potential_child]=noed_parent;
				rank[potential_child]=rank[noed_parent]+1;

				double weight0=connected_distance[noed_parent][i];
				weight[potential_child]=weight0;

				children[noed_parent][nr_child[noed_parent]++]=potential_child;
				node_id[len]=potential_child;
				len++;
				if(len>num_vertices)
				{
					printf("len>m_nr_vertices!!");
					getchar();
					exit(0);
				}
			}
		}
	}

	for(int i=0;i<num_vertices;i++)
	{
		node_seq.push_back(node_id[i]);
		nr_children_seq.push_back(nr_child[i]);
		parent_seq.push_back(parent[i]);
		weight_seq.push_back(weight[i]);
		vector<int> temp_child;
		for(int j=0;j<nr_child[i];j++)
		{
			temp_child.push_back(children[i][j]);
		}
		//temp_child.clear();
		children_seq.push_back(temp_child);

	}
	//////////////////////////////////////////////////////////////////display
	//Mat imgTemp0,imgTemp(10*m,10*n,CV_8UC3,Scalar(0,0,0));
	//resize(Guideimg[0],imgTemp0,Size(0,0),10,10);
	//for(int i=0;i<10*m;i++)
	//	for(int j=0;j<10*n;j++)
	//	{
	//		unsigned tt=(unsigned)int(255*imgTemp0.at<double>(i,j));
	//		imgTemp.at<Vec3b>(i,j)=Vec3b(tt,tt,tt);
	//	}
	//       
	//for(int i=0;i<(int)num_vertices;i++)
	//{		
	//	int sizec=nr_connected[i];
	//	int y1=10*(i/n)+5;
	//	int x1=10*(i%n)+5;
	//	for(int j=0;j<sizec;j++)
	//	{
	//		int id=connected[i][j];
	//		int y2=10*(id/n)+5;
	//		int x2=10*(id%n)+5;
	//		line(imgTemp,Point(x1,y1),Point(x2,y2),Scalar(255,0,0),2);
	//		//circle(imgL_temp,Point(x1,y1),3,Scalar(255,0,0),2);	
	//	}
	//	//Point P1(x1,y1),P2(x2,y2);			
	//}
	//namedWindow("tree_struct.png",WINDOW_NORMAL);
	//imshow("tree_struct.png",imgTemp);
	//waitKey();
	//imwrite("tree_struct.png",imgTemp);


	ST.clear();
	vector<Seg_Tree> temp0;
	ST.swap(temp0);
	freei_2(edge);
	delete []distance;
	distance=NULL;
	delete []id_edge;
	id_edge=NULL;

	delete[] parent;
	parent=NULL;

	delete []nr_child;
	nr_child=NULL;
	delete []weight;
	weight=NULL;
	delete []nr_connected;
	nr_connected=NULL;
	delete []node_id;
	node_id=NULL;
	delete []rank;
	rank=NULL;
    freei_2(children);
	freed_2(connected_distance);
	freei_2(connected);	
}

vector<Mat> Non_Local_filter(vector<Mat> Cost,vector<int> node_id,vector<int> nr_children,vector<vector<int>> children,vector<double> weight,vector<int> id_parent,double sigma)
{

	vector<Mat> Cost_backup((int)Cost.size());
	for(int i=0;i<(int)Cost.size();i++)
	{
		Cost_backup[i]=Cost[i].clone();
	}
	int m=Cost[0].rows;
	int n=Cost[0].cols;

	//vector<double> table=Search_in_Tabel(sigma);
	//vector<vector<double>> Cost_backup(Cost);
	int node_first=node_id[0];
	int Num_node=(int)node_id.size();
	int node_last=node_id[Num_node-1];
	for(int i=0; i<Num_node;i++)
	{
		int id=node_id[Num_node-1-i];//////////////////////leaves toward root ,so Num_node-1 first
		int x=id/n;
		int y=id%n;
		int nr_child=nr_children[id];

		if(nr_child>0)
		{													
			for (int d=0;d<(int)Cost.size();d++)
			{	
				double value_sum=Cost_backup[d].at<double>(x,y);
				for(int j=0;j<nr_child;j++)
				{
					int id_child=children[id][j];
					double weight0=exp(-weight[id_child]/sigma);
					int x1=id_child/n;
					int y1=id_child%n;
					double value_child=Cost_backup[d].at<double>(x1,y1);

					value_sum+=value_child*weight0;
				}
				Cost_backup[d].at<double>(x,y)=value_sum;
			}
		}
	}	
	////////////////////////////////////////leaf to root
	int rootx=node_first/n;
	int rooty=node_first%n;
	/*vector<Mat> out((int)Cost.size());
	for(int i=0;i<(int)Cost.size();i++)
	{
		out[i]=Mat(m,n,CV_64FC1,Scalar(0.0));
	}*/
	for(int d=0;d<(int)Cost.size();d++)
	{
		Cost[d].at<double>(rootx,rooty)=Cost_backup[d].at<double>(rootx,rooty);/////////////root is the same
	}

	for(int i=1; i<Num_node;i++)
	{
		int id=node_id[i];
		int parent=id_parent[id];
		int x=id/n;
		int y=id%n;
		int px=parent/n;
		int py=parent%n;
		for (int d=0;d<(int)Cost.size();d++)
		{	
			double value_parent=Cost[d].at<double>(px,py);
			double value_current=Cost_backup[d].at<double>(x,y);
			double weight0=exp(-weight[id]/sigma);
			Cost[d].at<double>(x,y)=weight0*value_parent+(1-weight0*weight0)*value_current;
		}

	}
	return Cost;
}
void compute_MLE(Mat train,Mat &mu,Mat &sigma)
{
	int num_train=train.rows;
	int channel=train.cols;
	
	mu=Mat(1,channel,CV_64FC1,Scalar(0));
	for(int i=0;i<num_train;i++)
	{
		for(int j=0;j<channel;j++)
		{
			mu.at<double>(0,j)+=train.at<double>(i,j);
		}
	}
	for(int j=0;j<channel;j++)
	{
		mu.at<double>(0,j)/=(double)num_train;
	}
	sigma=Mat(channel,channel,CV_64FC1,Scalar(0));
	if(num_train>channel)
	{
		for(int i=0;i<num_train;i++)
		{
			Mat temp=train.row(i)-mu;
			sigma+=temp.t()*temp;

		}
		sigma=sigma/((double)num_train);
	}
	else
	{
		for(int i=0;i<channel;i++)
		{
			double temp=0.0;
			for(int j=0;j<num_train;j++)
			{
				temp+=pow(train.at<double>(j,i)-mu.at<double>(0,i),2.0);
			}
			if(temp>0)
			   sigma.at<double>(i,i)=sqrt(temp/((double)num_train-1.0));
			else
			   sigma.at<double>(i,i)=1.0;			
		}
	}	
}
double compute_Gauss_PDF(Mat mu,Mat sigma,Mat sample)
{
	//FileStorage fs("1.xml",FileStorage::WRITE);
	//fs<<"mu"<<mu;
	//fs<<"sigma"<<sigma;
	//fs<<"sample"<<sample;
	//fs.release();
	int d=sample.cols;
	double constant=sqrt(pow(2*CV_PI,d));	
	//cout<<sigma<<endl;
	double determin_sigma=sqrt(determinant(sigma));
	if(determin_sigma==0)
		cout<<sigma<<endl;
	Mat dist_ma=(sample-mu)*((sigma+0.0001*Mat::eye(d,d,CV_64FC1)).inv(DECOMP_CHOLESKY))*((sample-mu).t());
	//cout<<dist_ma<<endl;
	double prob=1.0/(constant*determin_sigma)*exp(-0.5*dist_ma.at<double>(0,0));
	return prob;
}
Mat EM_Semi_Supervised_classification(Mat train,Mat test,Mat labs,int class_num,Mat& out,double beta=0.5)
{
	int channel=train.cols;
	int train_num=train.rows;
	vector<vector<int>> index_train(class_num);
	for(int i=0;i<train_num;i++)
		index_train[(int)labs.at<int>(i,0)-1].push_back(i);
	double*W=new double[class_num];
	vector<Mat> mu(class_num);
	vector<Mat> sigma(class_num);

	//////////////////////initialization
	for(int i=0;i<class_num;i++)
	{
		int num_in_class=(int)index_train[i].size();
		Mat train_in_class(num_in_class,channel,CV_64FC1,Scalar(0.0));
		for(int j=0;j<num_in_class;j++)
		{
			for(int s=0;s<channel;s++)
				train_in_class.at<double>(j,s)=train.at<double>(index_train[i][j],s);
		}
		compute_MLE(train_in_class,mu[i],sigma[i]);
		W[i]=(double)num_in_class/(double)train_num;
	}
	////////////////////////////////////
	Mat mu_1(class_num,channel,CV_64FC1,Scalar(0));
	//vector<Mat> sigma_1(class_num);
	for(int i=0;i<class_num;i++)
	{
		for(int j=0;j<channel;j++)
		{
			mu_1.at<double>(i,j)=mu[i].at<double>(0,j)*(double)index_train[i].size();
		}
	//	sigma_1[i]=sigma[i]*(double)index_train[i].size();
	}

	int test_num=test.rows;
	double **prob=new double*[test_num];
	for(int i=0;i<test_num;i++)
		prob[i]=new double[class_num];
	int iteration=0;
	bool judgement=true;
	double error_last=1e+20;
	while(iteration<1000&&judgement)
	{
		vector<Mat> mu_last(class_num);
		//vector<Mat> sigma_last(class_num);
		for(int i=0;i<class_num;i++)
		{
			mu_last[i]=mu[i].clone();
			//sigma_last[i]=sigma[i].clone();
		}

		//////////////e-step;
		for(int i=0;i<test_num;i++)
		{
			double temp=0.0;
			for(int j=0;j<class_num;j++)
			{
				prob[i][j]=W[j]*compute_Gauss_PDF(mu[j],sigma[j],test.row(i));
				/*cout<<prob[i][j]<<endl;
				cout<<mu[j]<<endl;
				cout<<sigma[j]<<endl;*/
				temp+=prob[i][j];
			}
			if(temp==0)
				continue;
			//double maxprob=prob[i][0]/temp;
			for(int j=0;j<class_num;j++)
			{	
				prob[i][j]/=temp;
			}
		}
		//////////////m-step;
		for(int i=0;i<class_num;i++)
		{
			mu[i]=(mu_1.row(i)).clone();
			double temp=0.0;
			for(int j=0;j<test_num;j++)
			{
				mu[i]+=beta*prob[j][i]*test.row(j);
				temp+=beta*prob[j][i];
			}
			mu[i]/=(temp+(double)index_train[i].size());
		}
		for(int i=0;i<class_num;i++)
		{
			Mat e_ik(channel,channel,CV_64FC1,Scalar(0.0));
			for(int j=0;j<(int)index_train[i].size();j++)
			{
				Mat temp1=(train.row(index_train[i][j])-mu[i]);
				e_ik+=temp1.t()*temp1;
			}
			double temp=0.0;
			for(int j=0;j<test_num;j++)
			{
				Mat temp1=(test.row(j)-mu[i]);
				e_ik+=beta*prob[j][i]*temp1.t()*temp1;
				temp+=beta*prob[j][i];
			}			
			sigma[i]=e_ik/((double)index_train[i].size()+temp);
			if(determinant(sigma[i])==0)
				sigma[i]+=0.0001*Mat::eye(channel,channel,CV_64FC1);
			W[i]=((double)index_train[i].size()+temp)/(train_num+beta*test_num);
		}		
		double erro=0.0;
		for(int i=0;i<class_num;i++)
		{	
			erro+=norm(mu[i],mu_last[i],NORM_L1);
		}
		if(erro>error_last)
			judgement=false;
		else
			error_last=erro;
		iteration++;
	}
	Mat Proba(test_num,class_num,CV_64FC1,Scalar(0));
	for(int i=0;i<test_num;i++)
	{
		for(int j=0;j<class_num;j++)
		{
			Proba.at<double>(i,j)=prob[i][j];
		}
	}
	Mat out(test_num,1,CV_32SC1,Scalar(0));
	for(int i=0;i<test_num;i++)
	{
		double temp=prob[i][0];
		int k=0;
		for(int j=1;j<class_num;j++)
		{
			if(prob[i][j]>temp)
			{
				temp=prob[i][j];
				k=j;
			}
		}
		out.at<int>(i,0)=k+1;
	}
	delete[]W;
	W=NULL;
	for(int i=0;i<test_num;i++)
	{	
		delete[]prob[i];
		prob[i]=NULL;
	}
	delete[]prob;
	prob=NULL;
	return Proba;
}
Mat EM_Supervised_classification(Mat train,Mat test,Mat labs,int K,int class_num)
{
	int channel=train.cols;
	int train_num=train.rows;
	vector<vector<int>> index_train(class_num);
	for(int i=0;i<train_num;i++)
		index_train[(int)labs.at<int>(i,0)-1].push_back(i);
	vector<EM> vecEM(class_num);
	for(int i=0;i<class_num;i++)
	{
		int num_in_class=(int)index_train[i].size();
		Mat train_in_class(num_in_class,channel,CV_64FC1,Scalar(0.0));
		for(int j=0;j<num_in_class;j++)
		{
			for(int s=0;s<channel;s++)
				train_in_class.at<double>(j,s)=train.at<double>(index_train[i][j],s);
		}
		//vector<Mat> loglikelihoods(K);
		vector<double>vecBIC(K);
		for(int j=0;j<K;j++)
		{
			Mat loglikelitemp;
			EM EMtemp(j+1,EM::COV_MAT_GENERIC,TermCriteria(TermCriteria::COUNT+TermCriteria::EPS,2000, FLT_EPSILON));
			EMtemp.train(train_in_class,loglikelitemp);
			double nParam=(double)j*(double)channel*((double)channel+1.0)/2.0;
			double BIC=-2.0*(sum(loglikelitemp).val[0])+log((double)num_in_class)*(nParam+(double)j-1.0+(double)j*(double)channel);
			vecBIC[j]=BIC;
		}
		int kk=0;
		double minBIC=vecBIC[0];
		for(int j=1;j<K;j++)
		{
			if(vecBIC[j]<minBIC)
			{
				minBIC=vecBIC[j];
				kk=j;
			}
		}
		EM EMtemp2(kk+1,EM::COV_MAT_GENERIC,TermCriteria(TermCriteria::COUNT+TermCriteria::EPS,2000, FLT_EPSILON));
		EMtemp2.train(train_in_class);
		vecEM[i]=EMtemp2;
	}
	Mat out(test.rows,1,CV_32SC1,Scalar(0));
	for(int i=0;i<test.rows;i++)
	{
		Mat temp=(test.row(i)).clone();
		Mat likeli(1,class_num,CV_64FC1,Scalar(0.0));
		double sum=0.0;
		for(int j=0;j<class_num;j++)
		{
			Vec2d d2=vecEM[j].predict(temp);
			likeli.at<double>(0,j)=d2[0];
			//sum+=likeli.at<double>(0,j);
		}
		//for(int j=0;j<class_num;j++)
		//{
		//	out.at<double>(i,j)=likeli.at<double>(0,j);//sum;
		//}

		Point2i maxloc;
		minMaxLoc(likeli,NULL,NULL,NULL,&maxloc);
		out.at<int>(i,0)=maxloc.x+1;
	}
	return out;
}
Mat seim_supervised_knn(Mat trainData,Mat trainlabels,Mat testData,int K,int C,int q)
{
	int num_train=trainData.rows;
	int channel=trainData.cols;
	int num_test=testData.rows;
	trainData.convertTo(trainData,CV_32FC1);
	testData.convertTo(testData,CV_32FC1);
	SYSTEM_INFO info;
	GetSystemInfo(&info);
	flann::KDTreeIndexParams indexParams((int)info.dwNumberOfProcessors);
	flann::Index kdtree_train(trainData,indexParams,cvflann::FLANN_DIST_L2);
	Mat indices_train,dists_train;
	kdtree_train.knnSearch(testData,indices_train,dists_train,K+1);
	flann::Index kdtree_test(testData,indexParams,cvflann::FLANN_DIST_L2);
	Mat indices_test,dists_test;
	kdtree_test.knnSearch(testData,indices_test,dists_test,C+1);
	double maxval,minval;
	minMaxLoc(trainlabels,&minval,&maxval);
	int class_num=int(maxval-minval+1);
	Mat out(num_test,class_num,CV_64FC1,Scalar(0.0));
	for(int i=0;i<num_test;i++)
	{
		Mat Probability(K,C+1,CV_64FC1,Scalar(0.0));
		//int ind_train=indices_train .at<int>(i,K);	
		for(int j=0;j<C+1;j++)
		{
			int ind_test=indices_test.at<int>(i,j);
			/*double dist_basic=0.0;
			for(int s=0;s<channel;s++)
			{
				dist_basic+=pow(abs(trainData.at<float>(ind_train,s)-testData.at<float>(ind_test,s)),q);
			}*/
			double *dist=new double[K];
			
			for(int s=0;s<K;s++)
			{
				dist[s]=0.0;
				int ind_train_cur=indices_train.at<int>(i,s);
				for(int t=0;t<channel;t++)
				{
					dist[s]+=pow(abs(trainData.at<float>(ind_train_cur,t)-testData.at<float>(ind_test,t)),q);
				}
				dist[s]=pow(dist[s],1.0/(double)q);
				Probability.at<double>(s,j)=dist[s];
				/*if(dist_basic!=0)
				    Probability.at<double>(s,j)=exp(-dist[s]/dist_basic/2.0)/(sqrt(2.0)*CV_PI);
				else
					Probability.at<double>(s,j)=1.0;*/
			}
			delete[]dist;
			dist=NULL;
		}
		
		for(int j=0;j<K;j++)
		{
			double maxval;
			minMaxLoc(Probability.row(j),NULL,&maxval);				
			for(int s=0;s<C+1;s++)
			{
				if(maxval==0)
					Probability.at<double>(j,s)=1.0;
				else
					Probability.at<double>(j,s)=exp(-Probability.at<double>(j,s)/maxval/2.0)/(sqrt(2.0)*CV_PI);
			}
		}
		
		double* hist=new double [class_num];
		for(int j=0;j<class_num;j++)
			hist[j]=0.0;
		for(int s=0;s<K;s++)
		{
			int ind_train_cur=indices_train.at<int>(i,s);
			int labs=trainlabels.at<int>(ind_train_cur,0);
			double temp=1.0;
			for(int j=0;j<C+1;j++)
			{
				temp*=Probability.at<double>(s,j);
			}
			hist[labs-(int)minval]+=temp;
		}
		double allhist=0.0;
		for(int j=0;j<class_num;j++)
			allhist+=hist[j];
		for(int j=0;j<class_num;j++)
		{
			if(allhist!=0)
				out.at<double>(i,j)=hist[j]/allhist;
			else
				out.at<double>(i,j)=0.0;		
		}
		delete[]hist;
		hist=NULL;
	}
	return out;
}