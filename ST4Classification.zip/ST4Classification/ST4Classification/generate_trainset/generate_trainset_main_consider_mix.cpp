#include <time.h>
#include <opencv2/core/core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\opencv.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <opencv2/ml/ml.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include "generate_trainset.h"
using namespace std;
using namespace cv;
int main(int argc, char* argv[])
{
	int m=atoi(argv[2]);
	int n=atoi(argv[3]);
	int num_lab=atoi(argv[4]);
	ifstream infile(argv[1],ios::binary);
	int num4labels=atoi(argv[5]);
	if(!infile)
	{
		cerr<<"open error!"<<endl;
		abort();
	}
	double **img=allocd_2(m,n);
	for(int j=0;j<n;j++)
	{
		for(int i=0;i<m;i++)
		{
			infile.read((char*)&img[i][j],sizeof(double));
		}
	}
	infile.close();
	vector<vector<points_GT>> GT_list_inner(num_lab);
	vector<vector<points_GT>> GT_list_edge(num_lab);
    Mat Mask(m,n,CV_8UC1,Scalar(0));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			int lab=(int)img[i][j];
			if(lab==0)
				continue;
			Mask.at<uchar>(i,j)=lab;
			points_GT temp;
			temp.x=i;
			temp.y=j;
			temp.lab=lab;
			if(isinner(img,i,j,m,n))
			{
				GT_list_inner[lab-1].push_back(temp);	
			}
			else
			{
				GT_list_edge[lab-1].push_back(temp);
			}		
		}
	}
	FileStorage fs;
	fs.open("Mask.xml",FileStorage::WRITE);
	fs<<"Mask"<<Mask;
	fs.release();
	vector<vector<points_GT>> train_list(num_lab);
	
	for(int i=0;i<num_lab;i++)
	{
		int numbers_in=GT_list_inner[i].size();
		int numbers_edge=GT_list_edge[i].size();
		int drawnum=(numbers_in+numbers_edge)/2;
		//if(num4labels>(numbers_in+numbers_edge))
		//{
		//	train_list[i]=GT_list_inner[i];
		//	for(int j=0;j<numbers_edge;j++)
		//	{
		//		train_list[i].push_back(GT_list_edge[i][j]);
		//	}
		//}
		if(num4labels<=numbers_in/2)
		{
			train_list[i]=choose_random_point(GT_list_inner[i],int(0.8f*(float)num4labels));
			vector<points_GT> temp=choose_random_point(GT_list_edge[i],int(0.2f*(float)num4labels));
			train_list[i].insert(train_list[i].end(),temp.begin(),temp.end());
		}
		else if(drawnum<numbers_in&&0.3f*(float)drawnum<numbers_edge)
		{
			train_list[i]=choose_random_point(GT_list_inner[i],int(0.7f*(float)drawnum));
			vector<points_GT> temp=choose_random_point(GT_list_edge[i],int(0.3f*(float)drawnum));
			train_list[i].insert(train_list[i].end(),temp.begin(),temp.end());
		}
		else
		{
			vector<points_GT> temp=GT_list_edge[i];
			temp.insert(temp.end(),GT_list_inner[i].begin(),GT_list_inner[i].end());
			train_list[i]=choose_random_point(temp,drawnum);
		}
		//else if(num4labels<drawnum&&drawnum<numbers_in)
		//{
		//	train_list[i]=GT_list_inner[i];
		//	vector<points_GT> temp=choose_random_point(GT_list_edge[i],num4labels-numbers_in);
		//	for(int j=0;j<num4labels-numbers_in;j++)
		//	{
		//		train_list[i].push_back(temp[j]);
		//	}
		//}
	}
	freed_2(img);
	FILE* fp=fopen("trainset.txt","wt");
	for(int i=0;i<num_lab;i++)
	{
		for(int j=0;j<train_list[i].size();j++)
		{
			fprintf(fp,"%d %d %d\n",train_list[i][j].x,train_list[i][j].y,train_list[i][j].lab);
		}
	}
	fclose(fp);
	FILE* fp1=fopen("Testset.txt","wt");
	for(int i=0;i<num_lab;i++)
	{
		for(int j=0;j<GT_list_inner[i].size();j++)
		{
			fprintf(fp1,"%d %d %d\n",GT_list_inner[i][j].x,GT_list_inner[i][j].y,GT_list_inner[i][j].lab);
		}
		for(int j=0;j<GT_list_edge[i].size();j++)
		{
			fprintf(fp1,"%d %d %d\n",GT_list_edge[i][j].x,GT_list_edge[i][j].y,GT_list_edge[i][j].lab);
		}
	}
	fclose(fp1);
	return 1;
}