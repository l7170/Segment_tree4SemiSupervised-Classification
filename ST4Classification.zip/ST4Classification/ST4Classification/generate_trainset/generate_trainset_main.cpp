#include <time.h>
#include <opencv2/core/core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\opencv.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <opencv2/ml/ml.hpp>
#include <iostream>
#include <fstream>
#include <string>
extern"C"
{
#include <f2c.h>
#include <clapack.h>
};
#include "generate_trainset.h"
using namespace std;
using namespace cv;
bool general_eig(Mat A,Mat B,Mat& eigen_vector,Mat& eigenval)  
{  
	integer N=A.cols;
	int n=A.cols;
	if (B.cols!= A.cols  || A.rows!=A.cols || B.rows!=A.cols)
		return false;
	eigen_vector=Mat::zeros(N,N,CV_64FC1);
	eigenval=Mat::zeros(1,N,CV_64FC1);
	integer itype=1;
	char JOBVT='V';
	char uplo='L';
	doublereal *AT=new doublereal[n*n];
	doublereal *BT=new doublereal[n*n];
	doublereal *w=new doublereal[n];
	doublereal *work=new doublereal[4*n];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			AT[j*n+i]=A.at<double>(i,j);
			BT[j*n+i]=B.at<double>(i,j);
		}
	}
	integer Lda=N;
	integer Ldb=N;
	integer   LWORK=4*n,INFO;

	dsygv_(&itype,&JOBVT,&uplo,&N,AT,&Lda,BT,&Ldb,w,work,&LWORK,&INFO);
	if(INFO==0)
	{
		for(int i=0;i<N;i++)
		{
			for(int j=0;j<N;j++)
				eigen_vector.at<double>(i,j)=AT[j*N+i];
		}
		for(int i=0;i<N;i++)
			eigenval.at<double>(0,i)=w[i];
		delete[]AT;AT=NULL;
		delete[]BT;BT=NULL;
		delete[]w;w=NULL;
		delete[]work;work=NULL;
		//cout<<eigen_vector<<endl;
		//cout<<eigenval<<endl;

		return true;	
	}
	else
	{
		delete[]AT;AT=NULL;
		delete[]BT;BT=NULL;
		delete[]w;w=NULL;
		delete[]work;work=NULL;
		return false;
	}

}  
void Max_heapify(double* a,int *order,int N,int i)
{
	int l=2*(i+1)-1;
	int r=2*(i+1);
	int largest;
	if(l<N&&a[l]>a[i])
	{
		largest=l;
	}
	else
		largest=i;
	if(r<N&&a[r]>a[largest])
		largest=r;
	if(largest!=i)
	{
		double temp=a[i];
		a[i]=a[largest];
		a[largest]=temp;
		double temp2=order[i];
		order[i]=order[largest];
		order[largest]=temp2;
		Max_heapify(a,order,N,largest);
	}

}
void Bulid_Max_heap(double* a,int*order,int N)
{
	for(int i=N/2-1;i>=0;i--)
	{
		Max_heapify(a,order,N,i);
	}
}
vector<int> heap_sort(double*a,int N,int K)
{
	int *order=new int[N];
	for(int i=0;i<N;i++)
		order[i]=i;
	Bulid_Max_heap(a,order,N);
	int length_a=N;
	int ii=0;
	while(ii<K)
	{
		double temp=a[0];
		a[0]=a[length_a-1];
		a[length_a-1]=temp;
		double temp2=order[0];
		order[0]=order[length_a-1];
		order[length_a-1]=temp2;
		length_a--;
		ii++;
		Max_heapify(a,order,N-ii,0);		
	}
	vector<int>out(K);
	for(int i=0;i<K;i++)
		out[i]=order[N-1-i];
	delete[]order;
	order=NULL;
	return out;
}
Mat SELF(Mat train,Mat lab,Mat test,double beta,double epsilon,double r,int K=7)
{
	int num_train=train.rows;
	int num_test=test.rows;
	if(train.cols!=test.cols||num_train!=lab.rows)
	{
		cout<<"error��training-set 's dimension isn't equal to tests' "<<endl;
		return Mat();
	}
	int channel=train.cols;
	double minlab,maxlab;
	minMaxLoc(lab,&minlab,&maxlab);
	int class_num=int(maxlab-minlab+1);
	vector<vector<int>> id(class_num);
	for(int i=0;i<num_train;i++)
	{
		int labels=(int)lab.at<int>(i,0);
		id[labels-1].push_back(i);
	}
	///////////////	
	double *sigma=new double[num_train];
	//int numall=num_train+num_test;
	double **dist2=new double*[num_train];
	for(int i=0;i<num_train;i++)
		dist2[i]=new double[num_train-i];

	for(int i=0;i<num_train;i++)
	{
		for(int j=i;j<num_train;j++)
		{
			double temp=0.0;
			for(int k=0;k<channel;k++)
				temp+=pow((train.at<double>(i,k)-train.at<double>(j,k)),2);
			dist2[i][j-i]=temp;
		}
	}
	double *temp=new double[num_train];
	for(int i=0;i<num_train;i++)
	{		
		for(int j=i;j<num_train;j++)
			temp[j]=-dist2[i][j-i];
		for(int j=0;j<i;j++)
			temp[j]=-dist2[j][i-j];
		vector<int>order_id=heap_sort(temp,num_train,K+1);
		int id=order_id[K];
		sigma[i]=-temp[id];		
	}
	delete[]temp;
	temp=NULL;
	Mat Wlb(num_train,num_train,CV_64FC1,Scalar(0));
	Mat Wlw(num_train,num_train,CV_64FC1,Scalar(0));
	for(int i=0;i<num_train;i++)
	{
		for(int j=i;j<num_train;j++)
		{
			if(lab.at<int>(i,0)==lab.at<int>(j,0))
			{
				int idx=(int)id[(int)lab.at<int>(i,0)-1].size();
				double A_ij=exp(-dist2[i][j-i]/sqrt(sigma[j]*sigma[i]));
				Wlb.at<double>(i,j)=A_ij*(1.0/num_train-1.0/idx);
				Wlb.at<double>(j,i)=Wlb.at<double>(i,j);
				Wlw.at<double>(i,j)=A_ij/(double)idx;
				Wlw.at<double>(j,i)=Wlw.at<double>(i,j);
			}
			else
			{
				Wlb.at<double>(i,j)=1.0/num_train;
				Wlb.at<double>(j,i)=Wlb.at<double>(i,j);
				Wlw.at<double>(i,j)=0.0;
				Wlw.at<double>(j,i)=0.0;
			}
		}
	}
	delete[]sigma;
	sigma=NULL;
	for(int i=0;i<num_train;i++)
	{
		delete[]dist2[i];
		dist2[i]=NULL;
	}
	delete[]dist2;
	dist2=NULL;
	Mat Llb(num_train,num_train,CV_64FC1,Scalar(0.0));
	Mat Llw(num_train,num_train,CV_64FC1,Scalar(0.0));
	for(int i=0;i<num_train;i++)
	{
		for(int j=0;j<num_train;j++)
		{
			Llw.at<double>(i,i)+=Wlw.at<double>(i,j);
			Llb.at<double>(i,i)+=Wlb.at<double>(i,j);
		}
	}
	Llb=Llb-Wlb;
	Llw=Llw-Wlw;
	/*cout<<Llb.row(0)<<endl;
	cout<<Llw.row(0)<<endl;*/
	//cout<<train.row(0)<<endl;
	Mat Slb=train.t()*Llb*train;
	Mat Slw=train.t()*Llw*train;
	/*cout<<Slb.row(0)<<endl;
	cout<<Slb.row(0)<<endl;*/
	Mat X(channel,num_train+num_test,CV_64FC1,Scalar(0));
	for(int i=0;i<num_train;i++)
	{
		for(int j=0;j<channel;j++)
			X.at<double>(j,i)=train.at<double>(i,j);
	}
	for(int i=0;i<num_test;i++)
	{
		for(int j=0;j<channel;j++)
			X.at<double>(j,i+num_train)=test.at<double>(i,j);
	}
	Mat mean_X(channel,1,CV_64FC1,Scalar(0));
	for(int i=0;i<channel;i++)
	{
		double temp=0;
		for(int j=0;j<num_train+num_test;j++)
			temp+=X.at<double>(i,j);
		temp/=(num_train+num_test);
		mean_X.at<double>(i,0)=temp;
	}
	Mat St=X*X.t()-(num_train+num_test)*mean_X*mean_X.t();
	Mat S_rlb=(1.0-beta)*Slb+beta*St;

	Mat S_rlw=(1.0-beta)*Slw+beta*Mat::eye(channel,channel,CV_64FC1);
	//cout<<S_rlw<<endl;
	Mat eigenvalue,eigenvector;
	if(general_eig(S_rlb,S_rlw,eigenvector,eigenvalue))
	{
		int choose_num;
		if(r>=1)
		{
			choose_num=(int)r;
		}
		else
		{
			double sum_temp=1.0/(sum(eigenvalue).val[0]);
			//cout<<eigenvalue<<endl;
			int k=channel-1;
			double temp=eigenvalue.at<double>(0,k);

			while(temp*sum_temp<r&&k>=0)
			{
				k--;
				temp+=eigenvalue.at<double>(0,k);
			}
			choose_num=channel-k;
		}
		//cout<<eigenvector.rows<<endl;
		//cout<<eigenvector.cols<<endl;
		//cout<<choose_num<<endl;
		//cout<<channel<<endl;
		Mat T=eigenvector(Range(0,channel),Range(channel-choose_num,channel));
		for(int i=0;i<choose_num;i++)
		{
			double scale=sqrt(eigenvalue.at<double>(0,channel-choose_num+i));
			for(int j=0;j<channel;j++)
				T.at<double>(j,i)*=scale;
		}	
		flip(T,T,1);
		return T;
	}
	else
	{
		cout<<"error!"<<endl;
		return Mat();	
	}
}
int main(int argc, char* argv[])
{
	if(argc==1)
	{
		cout<<"Usage: generate_trainset.exe gt.bin image_height image_width nunber_class generate_num_for_trainset num_bands test.bin"<<endl;
		cout<<"gt.bin------binary file recordgroundtruth by matlab file svmbylilu.m"<<endl;
		cout<<"image_height-----image height"<<endl;
		cout<<"image_width-----image width"<<endl;
		cout<<"nunber_class-----number of labels in train-set classification"<<endl;
		cout<<"generate_num_for_trainset-----the percent of each class you want to withdraw for grouping a trainingset"<<endl;
		cout<<"test.bin-------binary file record hyperspectral image, generate by matlab file mat2binary.m"<<endl;
		waitKey();
		exit(0);
	}
	int m=atoi(argv[2]);
	int n=atoi(argv[3]);
	int num_lab=atoi(argv[4]);
	ifstream infile(argv[1],ios::binary);
	double num4labels=atof(argv[5]);
	if(!infile)
	{
		cerr<<"open error!"<<endl;
		abort();
	}
	double **img1=allocd_2(m,n);
	for(int j=0;j<n;j++)
	{
		for(int i=0;i<m;i++)
		{
			infile.read((char*)&img1[i][j],sizeof(double));
		}
	}
	infile.close();



	vector<Vec3b> color_map(16);
	//std::srand((unsigned)time(NULL));
	//for(int i=0;i<maxnum_class;i++)
	//{
	//	color_map[i]=Vec3b((rand()%255),(rand()%255),(rand()%255));
	//}

	color_map[0]=Vec3b(255,0,0);
	color_map[1]=Vec3b(0,255,0);
	color_map[2]=Vec3b(0,0,255);
	color_map[3]=Vec3b(125,125,0);
	color_map[4]=Vec3b(0,125,125);
	color_map[5]=Vec3b(125,0,125);
	color_map[6]=Vec3b(100,200,100);
	color_map[7]=Vec3b(200,50,200);
	color_map[8]=Vec3b(120,60,200);
	color_map[9]=Vec3b(100,150,210);
	color_map[10]=Vec3b(80,180,210);
	color_map[11]=Vec3b(90,200,200);
	color_map[12]=Vec3b(100,220,80);
	color_map[13]=Vec3b(70,10,20);
	color_map[14]=Vec3b(60,50,30);
	color_map[15]=Vec3b(30,50,20);
	Mat GT_png(m,n,CV_8UC3,Scalar(0,0,0));
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(img1[i][j]!=0.0)
			{
				GT_png.at<Vec3b>(i,j)=color_map[(int)(img1[i][j]-1)];
			}
		}
	}
	imwrite("GT.png",GT_png);
	imshow("GT.png",GT_png);
	waitKey();

	vector<vector<points_GT>> GT_list_inner(num_lab);
    Mat Mask(m,n,CV_8UC1,Scalar(0));
	int allnum=0;
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			int lab=(int)img1[i][j];
			if(lab==0)
				continue;
			allnum++;
			Mask.at<uchar>(i,j)=lab;
			points_GT temp;
			temp.x=i;
			temp.y=j;
			temp.lab=lab;	
			GT_list_inner[lab-1].push_back(temp);			
		}
	}
    freed_2(img1);
	int channel=atoi(argv[6]);
	ifstream infile2(argv[7],ios::binary);
	if(!infile2)
	{
		cerr<<"open error!"<<endl;
		abort();
	}
	double*** img=allocd_3(channel,m,n);
	for(int k=0;k<channel;k++)
	{
		for(int j=0;j<n;j++)
		{
			for(int i=0;i<m;i++)
			{
				infile2.read((char*)&img[k][i][j],sizeof(double));
			}
		}
	}
	infile2.close();

	vector<vector<points_GT>> train_list(num_lab);	
	for(int i=0;i<num_lab;i++)
	{
		int numbers_in=GT_list_inner[i].size();
		//if(num4labels>(numbers_in+numbers_edge))
		//{
		//	train_list[i]=GT_list_inner[i];
		//	for(int j=0;j<numbers_edge;j++)
		//	{
		//		train_list[i].push_back(GT_list_edge[i][j]);
		//	}
		//}
		////////////////////////0.01:0.25
		int temp=(int)(numbers_in*0.01+0.5);
		temp=(temp>2 ? temp:2);
		train_list[i]=choose_random_point(GT_list_inner[i],temp);
		
	/*	if(num4labels<=numbers_in/2)
		{
			train_list[i]=choose_random_point(GT_list_inner[i],num4labels);
		}
		else
		{
			train_list[i]=choose_random_point(GT_list_inner[i],numbers_in/2);
		}*/
		//else if(num4labels<drawnum&&drawnum<numbers_in)
		//{
		//	train_list[i]=GT_list_inner[i];
		//	vector<points_GT> temp=choose_random_point(GT_list_edge[i],num4labels-numbers_in);
		//	for(int j=0;j<num4labels-numbers_in;j++)
		//	{
		//		train_list[i].push_back(temp[j]);
		//	}
		//}
	}

	int num_trainset=0;
	//FILE* fp=fopen("trainset.txt","wt");
	for(int i=0;i<num_lab;i++)
	{
		num_trainset+=(int)train_list[i].size();
	}
	//fclose(fp);
	//FILE* fp1=fopen("Testset.txt","wt");
	//for(int i=0;i<num_lab;i++)
	//{
	//	for(int j=0;j<GT_list_inner[i].size();j++)
	//	{
	//		fprintf(fp1,"%d %d %d\n",GT_list_inner[i][j].x,GT_list_inner[i][j].y,GT_list_inner[i][j].lab);
	//	}
	//}
	//fclose(fp1);

	
	Mat labelsMat(num_trainset,1,CV_32SC1,Scalar(0));
	Mat trainingDataMat(num_trainset,channel,CV_64FC1,Scalar(0));
	Mat train(num_trainset,3,CV_32SC1,Scalar(0));
	int id=0;
	for(int i=0;i<num_lab;i++)
	{
		for(int j=0;j<train_list[i].size();j++)
		{

			labelsMat.at<int>(id,0)=(int)train_list[i][j].lab;
			int row=train_list[i][j].x;
			int col=train_list[i][j].y;
			train.at<int>(id,0)=row;
			train.at<int>(id,1)=col;
			train.at<int>(id,2)=train_list[i][j].lab;
			for(int k=0;k<channel;k++)
			{			
				trainingDataMat.at<double>(id,k)=img[k][row][col];
			}
			id++;
		}
	}
	
	int idt=0;
	Mat testDataMat(allnum-num_trainset,channel,CV_64FC1,Scalar(0));
	Mat testlab(allnum-num_trainset,3,CV_32SC1,Scalar(0));
	for(int i=0;i<num_lab;i++)
	{
		for(int j=0;j<GT_list_inner[i].size();j++)
		{
			int row=GT_list_inner[i][j].x;
			int col=GT_list_inner[i][j].y;
			testlab.at<int>(idt,0)=row;
			testlab.at<int>(idt,1)=col;
			testlab.at<int>(idt,2)=GT_list_inner[i][j].lab;
			for(int k=0;k<channel;k++)
			{			
				testDataMat.at<double>(idt,k)=img[k][row][col];
			}
			idt++;
		}
	}
//	//{
//		double *maxval=new double[channel];
//		double *minval=new double[channel];
//		for(int i=0;i<channel;i++)
//		{
//			minMaxLoc(trainingDataMat.col(i),&minval[i],&maxval[i]);
//		}
//		for(int i=0;i<num_trainset;i++)
//		{
//			for(int j=0;j<channel;j++)
//			{
//				trainingDataMat.at<double>(i,j)=(trainingDataMat.at<double>(i,j)-minval[j])/maxval[j];
//			}		
//		}
//		for(int i=0;i<allnum-num_trainset;i++)
//		{
//			for(int j=0;j<channel;j++)
//			{
//				testDataMat.at<double>(i,j)=(testDataMat.at<double>(i,j)-minval[j])/maxval[j];
//			}
//		}
//
//	//}
//	
//	double beta=0.015,epslon=0.0001,r=10;
//	Mat W=SELF(trainingDataMat,labelsMat,testDataMat,beta,epslon,r);
//	
//	Mat trainingDataMat_ori=(trainingDataMat*W);
//	int ch=trainingDataMat_ori.cols;
//	///////////////////////////////Scale to [-1,1]
//	Mat scale4channel(ch,2,CV_64FC1,Scalar(0.0));
//	for(int i=0;i<ch;i++)
//	{
//		double maxval=0,minval=0;
//		minMaxLoc(trainingDataMat_ori.col(i),&minval,&maxval);
//		double scale=0.5f*double(maxval-minval);
//		double offset=double(minval+scale);
//		scale4channel.at<double>(i,0)=scale;
//		scale4channel.at<double>(i,1)=offset;
//	}
//	
//	for(int j=0;j<ch;j++)
//	{
//		double scale=scale4channel.at<double>(j,0);
//		double offset=scale4channel.at<double>(j,1);
//		for(int i=0;i<num_trainset;i++)
//		{
//			trainingDataMat_ori.at<double>(i,j)=(trainingDataMat.at<double>(i,j)-offset)/scale;
//		}
//	}
//	//trainingDataMat_ori=trainingDataMat;
//	FILE* fpoutrain=fopen("train.xml","wt");
//	for(int i=0;i<num_trainset;i++)
//	{
//		fprintf(fpoutrain,"%d ",(int)labelsMat.at<int>(i,0));
//		for(int j=0;j<ch;j++)
//		{
//			fprintf(fpoutrain,"%d:%f ",j+1,trainingDataMat_ori.at<double>(i,j));
//		}
//		fprintf(fpoutrain,"\n");
//	}
//	fclose(fpoutrain);
//
//
//	FILE* fpoutest=fopen("test.xml","wt");
//	int total_test=0;
////	vector<Point2i> testid;
//	Mat labtest(allnum,1,CV_32SC1,Scalar(0));
//	Mat test_ori(allnum,channel,CV_64FC1,Scalar(0));
//	int idall=0;
//	for(int i=0;i<m;i++)
//	{
//		for(int j=0;j<n;j++)
//		{	
//			if(Mask.at<uchar>(i,j))
//			{
//				Mat sampleMat(1,channel,CV_64FC1,Scalar(0));
//				labtest.at<int>(idall,0)=(int)Mask.at<uchar>(i,j);
//				fprintf(fpoutest,"%d ",(int)Mask.at<uchar>(i,j));
//				for(int k=0;k<channel;k++)
//				{	
//					sampleMat.at<double>(0,k)=(img[k][i][j]-minval[k])/maxval[k];
//				}
//
//				Mat trans_sampleMat=sampleMat*W;
//				for(int k=0;k<ch;k++)
//				{	
//					test_ori.at<double>(idall,k)=trans_sampleMat.at<double>(0,k);//(trans_sampleMat.at<double>(0,k)-scale4channel.at<double>(k,1))/scale4channel.at<double>(k,0);
//					fprintf(fpoutest,"%d:%lf ",k+1,test_ori.at<double>(idall,k));
//					test_ori.at<double>(idall,k)=test_ori.at<double>(idall,k);
//				}
//				fprintf(fpoutest,"\n");
//				//Mat result;
//				//float response = SVM.predict(sampleMat);
//				//SVM.predict(sampleMat,result);
//				//cout<<result<<endl;
//				//labels_svm.at<int>(i,j)=(int)response;
//				idall++;
//			//	testid.push_back(Point2i(i,j));
//			}			
//		}
//	}
//	fclose(fpoutest);
//	vector<Mat> SELFMAT;
//	for(int i=0;i<ch;i++)
//	{
//		SELFMAT.push_back(Mat(m,n,CV_64FC1,Scalar(0.0)));
//	}
//	Mat SELFJPG(m,n,CV_8UC3,Scalar(0,0,0));
//	for(int i=0;i<m;i++)
//	{
//		for(int j=0;j<n;j++)
//		{	
//			Mat sampleMat(1,channel,CV_64FC1,Scalar(0));
//			for(int k=0;k<channel;k++)
//			{	
//				sampleMat.at<double>(0,k)=(img[k][i][j]-minval[k])/maxval[k];
//			}
//			Mat trans_sampleMat=sampleMat*W;
//			for(int k=0;k<ch;k++)
//			{
//				SELFMAT[k].at<double>(i,j)=trans_sampleMat.at<double>(0,k);//(trans_sampleMat.at<double>(0,k)-scale4channel.at<double>(k,1))/scale4channel.at<double>(k,0);
//			}
//		}
//	}
	//delete[]minval;minval=NULL;
	//delete[]maxval;maxval=NULL;
	//for(int k=0;k<3;k++)
	//{
	//	double minval0,maxval0;
	//	minMaxLoc(SELFMAT[k],&minval0,&maxval0);
	//	for(int i=0;i<m;i++)
	//	{
	//		for(int j=0;j<n;j++)
	//		{
	//			SELFJPG.at<Vec3b>(i,j)[k]=(uchar)(255*int((SELFMAT[k].at<double>(i,j)-minval0)/maxval0+0.5));
	//		}
	//	}
	//}
	

	//imwrite("SELF.jpg",SELFJPG);
	//imshow("SELF.jpg",SELFJPG);
	//waitKey();
	FileStorage fs;
	fs.open("Mask_0.01.xml",FileStorage::WRITE);
	fs<<"Mask"<<Mask;
	fs<<"labelsMat"<<labelsMat;
	fs<<"trainingDataMat_ori"<<trainingDataMat;
	fs<<"train"<<train;
	fs<<"testDataMat"<<testDataMat;
	fs<<"testlab"<<testlab;
	fs.release();

	////////////////////////////////////5%	
	for(int i=0;i<num_lab;i++)
	{
		int numbers_in=GT_list_inner[i].size();
		////////////////////////0.01,0.05,0.10,0.15,0.20,0.25;
		int train_num=(int)train_list[i].size();

		int temp=(int)((double(numbers_in+train_num))*0.05-(double)train_num+0.5);
		if(temp>0)
		{
			vector<points_GT> temp_GT;
			temp_GT=choose_random_point(GT_list_inner[i],temp);
			int num_push=temp_GT.size();
			for(int j=0;j<num_push;j++)
				train_list[i].push_back(temp_GT[j]);
		}
		
	}
	num_trainset=0;
	for(int i=0;i<num_lab;i++)
	{
		num_trainset+=(int)train_list[i].size();
	}

	{
		Mat labelsMat0(num_trainset,1,CV_32SC1,Scalar(0));
		Mat trainingDataMat0(num_trainset,channel,CV_64FC1,Scalar(0));
		Mat train0(num_trainset,3,CV_32SC1,Scalar(0));
		id=0;
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<train_list[i].size();j++)
			{

				labelsMat0.at<int>(id,0)=(int)train_list[i][j].lab;
				int row=train_list[i][j].x;
				int col=train_list[i][j].y;
				train0.at<int>(id,0)=row;
				train0.at<int>(id,1)=col;
				train0.at<int>(id,2)=train_list[i][j].lab;
				for(int k=0;k<channel;k++)
				{			
					trainingDataMat0.at<double>(id,k)=img[k][row][col];
				}
				id++;
			}
		}
		
		idt=0;
		Mat testDataMat0(allnum-num_trainset,channel,CV_64FC1,Scalar(0));
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<GT_list_inner[i].size();j++)
			{
				int row=GT_list_inner[i][j].x;
				int col=GT_list_inner[i][j].y;
				for(int k=0;k<channel;k++)			
					testDataMat0.at<double>(idt,k)=img[k][row][col];
				idt++;
			}
		}
		FileStorage fs1;
		fs1.open("Mask_0.05.xml",FileStorage::WRITE);
		fs1<<"Mask"<<Mask;
		fs1<<"labelsMat"<<labelsMat0;
		fs1<<"trainingDataMat_ori"<<trainingDataMat0;
		fs1<<"train"<<train0;
		fs1<<"testDataMat"<<testDataMat0;
		fs1.release();
	}
	//////////////////////////////////////////////10%
	for(int i=0;i<num_lab;i++)
	{
		int numbers_in=GT_list_inner[i].size();
		////////////////////////0.01,0.05,0.10,0.15,0.20,0.25;
		int train_num=(int)train_list[i].size();

		int temp=(int)((double(numbers_in+train_num))*0.1-(double)train_num+0.5);
		if(temp>0)
		{
			vector<points_GT> temp_GT;
			temp_GT=choose_random_point(GT_list_inner[i],temp);
			int num_push=temp_GT.size();
			for(int j=0;j<num_push;j++)
				train_list[i].push_back(temp_GT[j]);
		}

	}
	num_trainset=0;
	for(int i=0;i<num_lab;i++)
	{
		num_trainset+=(int)train_list[i].size();
	}

	{
		Mat labelsMat0(num_trainset,1,CV_32SC1,Scalar(0));
		Mat trainingDataMat0(num_trainset,channel,CV_64FC1,Scalar(0));
		Mat train0(num_trainset,3,CV_32SC1,Scalar(0));
		id=0;
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<train_list[i].size();j++)
			{

				labelsMat0.at<int>(id,0)=(int)train_list[i][j].lab;
				int row=train_list[i][j].x;
				int col=train_list[i][j].y;
				train0.at<int>(id,0)=row;
				train0.at<int>(id,1)=col;
				train0.at<int>(id,2)=train_list[i][j].lab;
				for(int k=0;k<channel;k++)
				{			
					trainingDataMat0.at<double>(id,k)=img[k][row][col];
				}
				id++;
			}
		}

		idt=0;
		Mat testDataMat0(allnum-num_trainset,channel,CV_64FC1,Scalar(0));
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<GT_list_inner[i].size();j++)
			{
				int row=GT_list_inner[i][j].x;
				int col=GT_list_inner[i][j].y;
				for(int k=0;k<channel;k++)			
					testDataMat0.at<double>(idt,k)=img[k][row][col];
				idt++;
			}
		}
		FileStorage fs2;
		fs2.open("Mask_0.1.xml",FileStorage::WRITE);
		fs2<<"Mask"<<Mask;
		fs2<<"labelsMat"<<labelsMat0;
		fs2<<"trainingDataMat_ori"<<trainingDataMat0;
		fs2<<"train"<<train0;
		fs2<<"testDataMat"<<testDataMat0;
		fs2.release();
	}
	//////////////////////////////////////////////15%
	for(int i=0;i<num_lab;i++)
	{
		int numbers_in=GT_list_inner[i].size();
		////////////////////////0.01,0.05,0.10,0.15,0.20,0.25;
		int train_num=(int)train_list[i].size();

		int temp=(int)((double(numbers_in+train_num))*0.15-(double)train_num+0.5);
		if(temp>0)
		{
			vector<points_GT> temp_GT;
			temp_GT=choose_random_point(GT_list_inner[i],temp);
			int num_push=temp_GT.size();
			for(int j=0;j<num_push;j++)
				train_list[i].push_back(temp_GT[j]);
		}

	}
	num_trainset=0;
	for(int i=0;i<num_lab;i++)
	{
		num_trainset+=(int)train_list[i].size();
	}

	{
		Mat labelsMat0(num_trainset,1,CV_32SC1,Scalar(0));
		Mat trainingDataMat0(num_trainset,channel,CV_64FC1,Scalar(0));
		Mat train0(num_trainset,3,CV_32SC1,Scalar(0));
		id=0;
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<train_list[i].size();j++)
			{

				labelsMat0.at<int>(id,0)=(int)train_list[i][j].lab;
				int row=train_list[i][j].x;
				int col=train_list[i][j].y;
				train0.at<int>(id,0)=row;
				train0.at<int>(id,1)=col;
				train0.at<int>(id,2)=train_list[i][j].lab;
				for(int k=0;k<channel;k++)
				{			
					trainingDataMat0.at<double>(id,k)=img[k][row][col];
				}
				id++;
			}
		}

		idt=0;
		Mat testDataMat0(allnum-num_trainset,channel,CV_64FC1,Scalar(0));
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<GT_list_inner[i].size();j++)
			{
				int row=GT_list_inner[i][j].x;
				int col=GT_list_inner[i][j].y;
				for(int k=0;k<channel;k++)			
					testDataMat0.at<double>(idt,k)=img[k][row][col];
				idt++;
			}
		}
		FileStorage fs3;
		fs3.open("Mask_0.15.xml",FileStorage::WRITE);
		fs3<<"Mask"<<Mask;
		fs3<<"labelsMat"<<labelsMat0;
		fs3<<"trainingDataMat_ori"<<trainingDataMat0;
		fs3<<"train"<<train0;
		fs3<<"testDataMat"<<testDataMat0;;
		fs3.release();
	}
	//////////////////////////////////////////////20%
	for(int i=0;i<num_lab;i++)
	{
		int numbers_in=GT_list_inner[i].size();
		////////////////////////0.01,0.05,0.10,0.15,0.20,0.25;
		int train_num=(int)train_list[i].size();
		int temp=(int)((double(numbers_in+train_num))*0.2-(double)train_num+0.5);
		if(temp>0)
		{
			vector<points_GT> temp_GT;
			temp_GT=choose_random_point(GT_list_inner[i],temp);
			int num_push=temp_GT.size();
			for(int j=0;j<num_push;j++)
				train_list[i].push_back(temp_GT[j]);
		}

	}
	num_trainset=0;
	for(int i=0;i<num_lab;i++)
	{
		num_trainset+=(int)train_list[i].size();
	}

	{
		Mat labelsMat0(num_trainset,1,CV_32SC1,Scalar(0));
		Mat trainingDataMat0(num_trainset,channel,CV_64FC1,Scalar(0));
		Mat train0(num_trainset,3,CV_32SC1,Scalar(0));
		id=0;
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<train_list[i].size();j++)
			{

				labelsMat0.at<int>(id,0)=(int)train_list[i][j].lab;
				int row=train_list[i][j].x;
				int col=train_list[i][j].y;
				train0.at<int>(id,0)=row;
				train0.at<int>(id,1)=col;
				train0.at<int>(id,2)=train_list[i][j].lab;
				for(int k=0;k<channel;k++)
				{			
					trainingDataMat0.at<double>(id,k)=img[k][row][col];
				}
				id++;
			}
		}

		idt=0;
		Mat testDataMat0(allnum-num_trainset,channel,CV_64FC1,Scalar(0));
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<GT_list_inner[i].size();j++)
			{
				int row=GT_list_inner[i][j].x;
				int col=GT_list_inner[i][j].y;
				for(int k=0;k<channel;k++)			
					testDataMat0.at<double>(idt,k)=img[k][row][col];
				idt++;
			}
		}
		FileStorage fs4;
		fs4.open("Mask_0.2.xml",FileStorage::WRITE);
		fs4<<"Mask"<<Mask;
		fs4<<"labelsMat"<<labelsMat0;
		fs4<<"trainingDataMat_ori"<<trainingDataMat0;
		fs4<<"train"<<train0;
		fs4<<"testDataMat"<<testDataMat0;;
		fs4.release();
	}
	//////////////////////////////////////////////25%
	for(int i=0;i<num_lab;i++)
	{
		int numbers_in=GT_list_inner[i].size();
		////////////////////////0.01,0.05,0.10,0.15,0.20,0.25;
		int train_num=(int)train_list[i].size();

		int temp=(int)((double(numbers_in+train_num))*0.25-(double)train_num+0.5);
		if(temp>0)
		{
			vector<points_GT> temp_GT;
			temp_GT=choose_random_point(GT_list_inner[i],temp);
			int num_push=temp_GT.size();
			for(int j=0;j<num_push;j++)
				train_list[i].push_back(temp_GT[j]);
		}

	}
	num_trainset=0;
	for(int i=0;i<num_lab;i++)
	{
		num_trainset+=(int)train_list[i].size();
	}

	{
		Mat labelsMat0(num_trainset,1,CV_32SC1,Scalar(0));
		Mat trainingDataMat0(num_trainset,channel,CV_64FC1,Scalar(0));
		Mat train0(num_trainset,3,CV_32SC1,Scalar(0));
		id=0;
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<train_list[i].size();j++)
			{

				labelsMat0.at<int>(id,0)=(int)train_list[i][j].lab;
				int row=train_list[i][j].x;
				int col=train_list[i][j].y;
				train0.at<int>(id,0)=row;
				train0.at<int>(id,1)=col;
				train0.at<int>(id,2)=train_list[i][j].lab;
				for(int k=0;k<channel;k++)
				{			
					trainingDataMat0.at<double>(id,k)=img[k][row][col];
				}
				id++;
			}
		}

		idt=0;
		Mat testDataMat0(allnum-num_trainset,channel,CV_64FC1,Scalar(0));
		for(int i=0;i<num_lab;i++)
		{
			for(int j=0;j<GT_list_inner[i].size();j++)
			{
				int row=GT_list_inner[i][j].x;
				int col=GT_list_inner[i][j].y;
				for(int k=0;k<channel;k++)			
					testDataMat0.at<double>(idt,k)=img[k][row][col];
				idt++;
			}
		}
		FileStorage fs5;
		fs5.open("Mask_0.25.xml",FileStorage::WRITE);
		fs5<<"Mask"<<Mask;
		fs5<<"labelsMat"<<labelsMat0;
		fs5<<"trainingDataMat_ori"<<trainingDataMat0;
		fs5<<"train"<<train0;
		fs5<<"testDataMat"<<testDataMat0;;
		fs5.release();
	}
	freed_3(img);
	return 1;
}