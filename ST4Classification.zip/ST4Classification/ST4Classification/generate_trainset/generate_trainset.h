#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <time.h>
#include <iostream>

#define _PADDING 10
using namespace std;
struct points_GT
{
	int x,y;
	int lab;
};
double ** allocd_2(int r,int c,int padding=_PADDING)
{
	double *a,**p;
	a=(double*) malloc(sizeof(double)*(r*c+padding));
	if(a==NULL) {printf("allocd_2() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(double**) malloc(sizeof(double*)*r);
	
	for(int i=0;i<r;i++) 
		p[i]=&a[i*c];

	return(p);
}
void freed_2(double **p)
{
	if(p!=NULL)
	{
		free(p[0]);
		free(p);
		p=NULL;
	}
}
double*** allocd_3(int n,int r,int c,int padding=_PADDING)
{
	double *a,**p,***pp;
	int rc=r*c;
	int i,j;
	a=(double*) malloc(sizeof(double)*(n*rc+padding));
	if(a==NULL) {printf("allocd_3() fail, Memory is too huge, fail.\n"); getchar(); exit(0); }
	p=(double**) malloc(sizeof(double*)*n*r);
	pp=(double***) malloc(sizeof(double**)*n);
	for(i=0;i<n;i++) 
		for(j=0;j<r;j++) 
			p[i*r+j]=&a[i*rc+j*c];
	for(i=0;i<n;i++) 
		pp[i]=&p[i*r];
	return pp;
}
void freed_3(double ***p)
{
	if(p!=NULL)
	{
		free(p[0][0]);
		free(p[0]);
		free(p);
		p=NULL;
	}
}
bool isinner(double **img,int i,int j,int m,int n)
{
	int lab=(int)img[i][j];
	if(i-1>=0)
	{
		if(img[i-1][j]!=lab)
			return false;
		if(j-1>=0)
			if(img[i-1][j-1]!=lab)
				return false;
		if(j+1<n)
			if(img[i-1][j+1]!=lab)
				return false;
	}
	if(i+1<m)
	{
		if(img[i+1][j]!=lab)
			return false;
		if(j-1>=0)
			if(img[i+1][j-1]!=lab)
				return false;
		if(j+1<n)
			if(img[i+1][j+1]!=lab)
				return false;
	}
	if(j-1>=0)
		if(img[i][j-1]!=lab)
			return false;
	if(j+1<n)
		if(img[i][j+1]!=lab)
			return false;
	return true;	
}
vector<points_GT> choose_random_point(vector<points_GT> &pointlist,int num)
{
	srand((unsigned)time(NULL));
	int totolnum=(int)pointlist.size();
	int n=0;
	vector<points_GT> out;
	while(n<num)
	{
		int tempout=totolnum*rand()/(RAND_MAX+1);
		out.push_back(pointlist[tempout]);
		vector<points_GT>::iterator it=pointlist.begin();
		it=pointlist.erase(it+tempout);
		totolnum--;
		if(totolnum<0)
			break;
		n++;
	}
	return out;
}
